#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_com_kun_github_config_NativeLib_getClientId(JNIEnv *env, jobject thiz) {
    std::string clientId = "自己填";
    return env->NewStringUTF(clientId.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_kun_github_config_NativeLib_getClientSecret(JNIEnv *env, jobject thiz) {
    std::string clientSecret = "自己填";
    return env->NewStringUTF(clientSecret.c_str());
}
