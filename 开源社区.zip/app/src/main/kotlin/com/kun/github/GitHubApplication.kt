package com.kun.github

import android.app.Application
import android.content.res.Configuration
import com.kun.github.presentation.settings.LanguageManager
import com.kun.github.utils.CrashHandler
import java.util.Locale

class GitHubApplication : Application() {
    
    override fun onCreate() {
        super.onCreate()
        
        // 注册Activity生命周期回调，用于崩溃时获取当前Activity
        CrashHandler.registerActivityLifecycleCallbacks(this)
        
        // 初始化崩溃日志捕获
        CrashHandler.init(this)
        
        // 在 Application 启动时设置默认语言
        val language = LanguageManager.getCurrentLanguage(this)
        val locale = when (language) {
            LanguageManager.AppLanguage.SYSTEM -> {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                    android.os.LocaleList.getDefault()[0]
                } else {
                    Locale.getDefault()
                }
            }
            LanguageManager.AppLanguage.CHINESE -> Locale.CHINESE
            LanguageManager.AppLanguage.ENGLISH -> Locale.ENGLISH
        }
        Locale.setDefault(locale)
    }
    
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // 系统语言变化时，如果设置为跟随系统则更新
        if (LanguageManager.getCurrentLanguage(this) == LanguageManager.AppLanguage.SYSTEM) {
            val locale = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                android.os.LocaleList.getDefault()[0]
            } else {
                Locale.getDefault()
            }
            Locale.setDefault(locale)
        }
    }
}
