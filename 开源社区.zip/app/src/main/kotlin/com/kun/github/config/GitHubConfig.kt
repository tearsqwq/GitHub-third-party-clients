package com.kun.github.config

/**
 * GitHub 配置常量
 * 
 * 职责：
 * - 管理 OAuth 客户端配置
 * - 定义 API 端点 URL
 * - 定义权限范围
 * 
 * 安全说明：
 * - CLIENT_ID 和 CLIENT_SECRET 从 NativeLib 获取
 * - 敏感信息存储在 native 层，增加逆向难度
 */
object GitHubConfig {
    
    // ==================== OAuth 配置 ====================
    
    /** OAuth 客户端 ID（从 native 层获取） */
    val CLIENT_ID: String = NativeLib.getClientId()
    
    /** OAuth 客户端密钥（从 native 层获取） */
    val CLIENT_SECRET: String = NativeLib.getClientSecret()
    
    /** OAuth 回调 URI */
    const val REDIRECT_URI = "github://oauth/callback"
    
    /** 
     * OAuth 权限范围
     * - user: 用户信息读写
     * - repo: 仓库读写
     * - delete_repo: 删除仓库
     */
    const val SCOPE = "user repo delete_repo"
    
    /** OAuth 授权 URL */
    const val AUTHORIZE_URL = "https://github.com/login/oauth/authorize"
    
    // ==================== API 端点 ====================
    
    /** OAuth API 基础 URL */
    const val BASE_URL_OAUTH = "https://github.com/"
    
    /** GitHub API 基础 URL */
    const val BASE_URL_API = "https://api.github.com/"
    
    // ==================== 常量 ====================
    
    /** 每页数据数量 */
    const val PER_PAGE = 30
    
    /** 请求超时时间（秒） */
    const val TIMEOUT_SECONDS = 30L
    
    /** 缓存大小（字节） */
    const val CACHE_SIZE_BYTES = 10L * 1024 * 1024 // 10MB
}
