package com.kun.github.config

object NativeLib {
    init {
        System.loadLibrary("native-lib")
    }

    external fun getClientId(): String
    external fun getClientSecret(): String
}
