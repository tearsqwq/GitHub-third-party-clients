package com.kun.github.data.local.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.accountsDataStore: DataStore<Preferences> by preferencesDataStore(name = "accounts")

/**
 * 账号信息
 */
data class GitHubAccount(
    val id: String,
    val username: String,
    val avatarUrl: String,
    val token: String,
    val isCurrent: Boolean = false
)

/**
 * 多账号管理器
 */
class AccountsManager(private val context: Context) {

    companion object {
        private val ACCOUNTS_KEY = stringPreferencesKey("accounts_json")
        private val CURRENT_ACCOUNT_KEY = stringPreferencesKey("current_account_id")
    }

    /**
     * 获取所有账号
     */
    val accountsFlow: Flow<List<GitHubAccount>> = context.accountsDataStore.data.map { preferences ->
        val json = preferences[ACCOUNTS_KEY] ?: "[]"
        parseAccountsJson(json)
    }

    /**
     * 获取当前账号
     */
    val currentAccountFlow: Flow<GitHubAccount?> = accountsFlow.map { accounts ->
        accounts.find { it.isCurrent }
    }

    /**
     * 添加新账号
     */
    suspend fun addAccount(account: GitHubAccount) {
        context.accountsDataStore.edit { preferences ->
            // 将所有账号的 isCurrent 设为 false
            val currentAccounts = preferences[ACCOUNTS_KEY]?.let { parseAccountsJson(it) } ?: emptyList()
            val updatedAccounts = currentAccounts.map { it.copy(isCurrent = false) } + account.copy(isCurrent = true)
            
            preferences[ACCOUNTS_KEY] = accountsToJson(updatedAccounts)
            preferences[CURRENT_ACCOUNT_KEY] = account.id
        }
    }

    /**
     * 切换到指定账号
     */
    suspend fun switchAccount(accountId: String) {
        context.accountsDataStore.edit { preferences ->
            val json = preferences[ACCOUNTS_KEY] ?: "[]"
            val accounts = parseAccountsJson(json)
            
            val updatedAccounts = accounts.map { it.copy(isCurrent = it.id == accountId) }
            preferences[ACCOUNTS_KEY] = accountsToJson(updatedAccounts)
            preferences[CURRENT_ACCOUNT_KEY] = accountId
        }
    }

    /**
     * 删除账号
     */
    suspend fun removeAccount(accountId: String) {
        context.accountsDataStore.edit { preferences ->
            val json = preferences[ACCOUNTS_KEY] ?: "[]"
            val accounts = parseAccountsJson(json).toMutableList()
            
            // 找到要删除的账号
            val accountToRemove = accounts.find { it.id == accountId }
            accounts.removeIf { it.id == accountId }
            
            // 如果删除的是当前账号，且还有其他账号，自动切换到第一个
            if (accountToRemove?.isCurrent == true && accounts.isNotEmpty()) {
                accounts[0] = accounts[0].copy(isCurrent = true)
                preferences[CURRENT_ACCOUNT_KEY] = accounts[0].id
            }
            
            preferences[ACCOUNTS_KEY] = accountsToJson(accounts)
        }
    }

    /**
     * 获取当前账号的 token
     */
    suspend fun getCurrentToken(): String? {
        return currentAccountFlow.first()?.token
    }

    /**
     * 获取当前账号
     */
    suspend fun getCurrentAccount(): GitHubAccount? {
        return currentAccountFlow.first()
    }

    /**
     * 解析 JSON 为账号列表
     */
    private fun parseAccountsJson(json: String): List<GitHubAccount> {
        return try {
            val array = JSONArray(json)
            (0 until array.length()).map { i ->
                val obj = array.getJSONObject(i)
                GitHubAccount(
                    id = obj.getString("id"),
                    username = obj.getString("username"),
                    avatarUrl = obj.optString("avatarUrl", ""),
                    token = obj.getString("token"),
                    isCurrent = obj.getBoolean("isCurrent")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * 账号列表转为 JSON
     */
    private fun accountsToJson(accounts: List<GitHubAccount>): String {
        val array = JSONArray()
        accounts.forEach { account ->
            val obj = JSONObject().apply {
                put("id", account.id)
                put("username", account.username)
                put("avatarUrl", account.avatarUrl)
                put("token", account.token)
                put("isCurrent", account.isCurrent)
            }
            array.put(obj)
        }
        return array.toString()
    }
}
