package com.kun.github.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * GitHub Event 数据模型
 * 用于获取用户的活动事件，包括 push 事件来统计贡献
 */
@Serializable
data class GithubEvent(
    val id: String,
    val type: String,
    val actor: GithubActor,
    val repo: GithubEventRepo,
    val payload: GithubPayload? = null,
    @SerialName("created_at") val createdAt: String
)

@Serializable
data class GithubActor(
    val id: Long,
    val login: String,
    @SerialName("avatar_url") val avatarUrl: String
)

@Serializable
data class GithubEventRepo(
    val id: Long,
    val name: String,
    val url: String
)

@Serializable
data class GithubPayload(
    @SerialName("push_id") val pushId: Long? = null,
    val size: Int = 0, // commit 数量
    @SerialName("distinct_size") val distinctSize: Int = 0,
    val ref: String? = null,
    val commits: List<GithubCommit>? = null
)

@Serializable
data class GithubCommit(
    val sha: String,
    val message: String,
    val author: GithubCommitAuthor
)

@Serializable
data class GithubCommitAuthor(
    val name: String,
    val email: String
)
