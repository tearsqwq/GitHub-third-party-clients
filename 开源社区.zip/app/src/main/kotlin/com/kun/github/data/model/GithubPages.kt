package com.kun.github.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class GithubPages(
    @SerialName("url") val url: String? = null,
    @SerialName("status") val status: String? = null,
    @SerialName("html_url") val htmlUrl: String? = null,
    @SerialName("source") val source: com.kun.github.data.remote.dto.PagesSource? = null
)
