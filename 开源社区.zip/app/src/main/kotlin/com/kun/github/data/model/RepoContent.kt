package com.kun.github.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class RepoContent(
    val name: String,
    @SerialName("path") val path: String,
    @SerialName("type") val type: String,
    @SerialName("size") val size: Int,
    @SerialName("html_url") val htmlUrl: String? = null,
    @SerialName("content") val content: String? = null,
    @SerialName("sha") val sha: String? = null
)
