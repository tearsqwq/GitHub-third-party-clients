package com.kun.github.data.remote.client

import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import com.kun.github.data.remote.api.GithubApi
import com.kun.github.data.remote.interceptor.AuthInterceptor
import com.kun.github.data.remote.interceptor.LoggingInterceptor
import com.kun.github.data.remote.interceptor.RetryInterceptor
import kotlinx.serialization.json.Json
import okhttp3.Cache
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * GitHub API 客户端单例
 * 
 * 职责：
 * - 管理 Retrofit + OkHttp 客户端实例
 * - 提供带认证的 API 接口
 * - 管理 HTTP 缓存
 * - 支持多账号切换
 * 
 * 优化点：
 * - 使用 ConcurrentHashMap 缓存不同 token 的客户端实例
 * - 统一配置超时、重试、日志等
 * - 支持缓存清理和客户端刷新
 */
object GithubApiClient {

    // ==================== 常量配置 ====================
    
    private const val BASE_URL_OAUTH = "https://github.com/"
    private const val BASE_URL_API = "https://api.github.com/"
    
    // 网络超时配置（秒）
    private const val CONNECT_TIMEOUT_SECONDS = 30L
    private const val READ_TIMEOUT_SECONDS = 30L
    private const val WRITE_TIMEOUT_SECONDS = 30L
    
    // 缓存大小：10MB
    private const val CACHE_SIZE_BYTES = 10L * 1024 * 1024
    
    // 重试配置
    private const val MAX_RETRY_COUNT = 3

    // ==================== JSON 配置 ====================
    
    /**
     * JSON 解析配置
     * - ignoreUnknownKeys: 忽略未知字段，提高兼容性
     * - coerceInputValues: 将 null 转为默认值
     * - isLenient: 宽松解析模式
     */
    private val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
        isLenient = true
        encodeDefaults = true
    }

    // ==================== 客户端缓存 ====================
    
    /**
     * API 客户端缓存
     * Key: token, Value: GithubApi 实例
     * 使用 ConcurrentHashMap 保证线程安全
     */
    private val apiClientCache = ConcurrentHashMap<String, GithubApi>()

    // ==================== 客户端构建 ====================
    
    /**
     * 创建基础 OkHttp 客户端（无认证）
     * 
     * @param cacheDir 缓存目录
     * @return OkHttpClient 实例
     */
    private fun createBaseClient(cacheDir: File? = null): OkHttpClient {
        return OkHttpClient.Builder().apply {
            // 超时配置
            connectTimeout(CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            readTimeout(READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            writeTimeout(WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            
            // 拦截器
            addInterceptor(LoggingInterceptor.create())
            addInterceptor(RetryInterceptor(MAX_RETRY_COUNT))
            
            // 缓存配置
            cacheDir?.let { dir ->
                cache(Cache(dir, CACHE_SIZE_BYTES))
            }
        }.build()
    }

    /**
     * 创建带认证的 OkHttp 客户端
     * 
     * @param token GitHub 访问令牌
     * @param cacheDir 缓存目录
     * @return OkHttpClient 实例
     */
    private fun createAuthClient(token: String, cacheDir: File? = null): OkHttpClient {
        return OkHttpClient.Builder().apply {
            // 超时配置
            connectTimeout(CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            readTimeout(READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            writeTimeout(WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            
            // 拦截器（按顺序执行）
            addInterceptor(AuthInterceptor(token))
            addInterceptor(LoggingInterceptor.create())
            addInterceptor(RetryInterceptor(MAX_RETRY_COUNT))
            
            // 缓存配置
            cacheDir?.let { dir ->
                cache(Cache(dir, CACHE_SIZE_BYTES))
            }
        }.build()
    }

    /**
     * 创建 Retrofit 实例
     * 
     * @param baseUrl 基础 URL
     * @param client OkHttp 客户端
     * @return Retrofit 实例
     */
    private fun createRetrofit(baseUrl: String, client: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
    }

    // ==================== 公共 API ====================
    
    /**
     * OAuth API 客户端（无需认证）
     * 使用 lazy 延迟初始化
     */
    val oauthApi: GithubApi by lazy {
        createRetrofit(BASE_URL_OAUTH, createBaseClient())
            .create(GithubApi::class.java)
    }

    /**
     * 创建带认证的 API 客户端
     * 
     * 特性：
     * - 使用缓存避免重复创建相同 token 的客户端
     * - 线程安全
     * 
     * @param token GitHub 访问令牌
     * @param cacheDir 缓存目录
     * @return GithubApi 实例
     */
    fun createAuthenticatedApi(token: String, cacheDir: File? = null): GithubApi {
        return apiClientCache.getOrPut(token) {
            createRetrofit(BASE_URL_API, createAuthClient(token, cacheDir))
                .create(GithubApi::class.java)
        }
    }

    // ==================== 缓存管理 ====================
    
    /**
     * 清除特定 token 的缓存客户端
     * 用于登出时清理资源
     * 
     * @param token 要清除的 token
     */
    fun clearCachedClient(token: String) {
        apiClientCache.remove(token)
    }

    /**
     * 清除所有缓存的客户端
     * 用于完全登出或清理资源
     */
    fun clearAllCachedClients() {
        apiClientCache.clear()
    }

    /**
     * 清除 HTTP 磁盘缓存
     * 
     * @param cacheDir 缓存目录
     */
    fun clearHttpCache(cacheDir: File?) {
        cacheDir?.let { dir ->
            dir.listFiles()?.forEach { it.deleteRecursively() }
        }
    }

    /**
     * 刷新特定 token 的 API 客户端
     * 
     * 使用场景：
     * - 上传文件后需要立即看到更新
     * - 切换账号后需要刷新缓存
     * 
     * @param token GitHub 访问令牌
     * @param cacheDir 缓存目录
     */
    fun refreshClient(token: String, cacheDir: File? = null) {
        // 移除旧客户端
        apiClientCache.remove(token)
        // 清除磁盘缓存
        clearHttpCache(cacheDir)
        // 新客户端会在下次 createAuthenticatedApi 调用时自动创建
    }
    
    /**
     * 获取当前缓存的客户端数量
     * 用于调试和监控
     */
    fun cachedClientCount(): Int = apiClientCache.size
}
