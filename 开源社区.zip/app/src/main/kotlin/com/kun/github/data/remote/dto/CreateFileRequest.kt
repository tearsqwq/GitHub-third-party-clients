package com.kun.github.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class CreateFileRequest(
    val message: String,
    val content: String, // Base64 encoded content
    @SerialName("branch") val branch: String? = null
)
