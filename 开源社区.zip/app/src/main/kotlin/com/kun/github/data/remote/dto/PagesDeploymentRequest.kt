package com.kun.github.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class PagesDeploymentRequest(
    @SerialName("source") val source: PagesSource
)

@Serializable
data class PagesSource(
    @SerialName("branch") val branch: String,
    @SerialName("path") val path: String = "/"
)
