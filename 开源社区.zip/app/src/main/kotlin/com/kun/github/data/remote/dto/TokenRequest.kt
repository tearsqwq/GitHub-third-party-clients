package com.kun.github.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class TokenRequest(
    val client_id: String,
    val client_secret: String,
    val code: String,
    val redirect_uri: String
)
