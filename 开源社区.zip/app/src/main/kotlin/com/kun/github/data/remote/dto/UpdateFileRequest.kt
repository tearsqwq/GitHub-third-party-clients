package com.kun.github.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class UpdateFileRequest(
    val message: String,
    val content: String, // Base64 encoded content
    val sha: String, // Required for updating existing file
    @SerialName("branch") val branch: String? = null
)
