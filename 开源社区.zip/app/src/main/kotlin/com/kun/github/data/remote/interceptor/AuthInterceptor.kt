package com.kun.github.data.remote.interceptor

import okhttp3.Interceptor
import okhttp3.Response

/**
 * 认证拦截器
 * 
 * 功能：
 * - 为请求添加 GitHub Bearer Token 认证头
 * - 支持多账号切换
 * 
 * @param token GitHub 个人访问令牌
 */
class AuthInterceptor(private val token: String) : Interceptor {
    
    companion object {
        const val HEADER_AUTHORIZATION = "Authorization"
        const val PREFIX_BEARER = "Bearer "
    }
    
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request().newBuilder()
            .addHeader(HEADER_AUTHORIZATION, "$PREFIX_BEARER$token")
            .build()
        return chain.proceed(request)
    }
}
