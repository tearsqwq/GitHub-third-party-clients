package com.kun.github.data.remote.interceptor

import okhttp3.logging.HttpLoggingInterceptor

/**
 * 日志拦截器工厂
 * 
 * 功能：
 * - 统一配置 HTTP 请求日志级别
 * - 使用 BASIC 级别避免打印完整响应体（防止大响应导致的性能问题）
 * 
 * 日志级别说明：
 * - NONE: 不记录日志
 * - BASIC: 只记录请求行和响应行（推荐）
 * - HEADERS: 记录请求和响应头
 * - BODY: 记录请求和响应体（可能影响性能）
 */
object LoggingInterceptor {
    
    /**
     * 创建日志拦截器
     * 
     * @param level 日志级别，默认 BASIC
     * @return HttpLoggingInterceptor 实例
     */
    fun create(
        level: HttpLoggingInterceptor.Level = HttpLoggingInterceptor.Level.BASIC
    ): HttpLoggingInterceptor {
        return HttpLoggingInterceptor().apply {
            this.level = level
        }
    }
    
    /**
     * 创建详细日志拦截器（用于调试）
     * 包含请求头和响应头
     */
    fun createVerbose(): HttpLoggingInterceptor {
        return create(HttpLoggingInterceptor.Level.HEADERS)
    }
    
    /**
     * 创建完整日志拦截器（用于深度调试）
     * 包含请求体和响应体
     * 注意：可能影响性能，仅用于调试
     */
    fun createFull(): HttpLoggingInterceptor {
        return create(HttpLoggingInterceptor.Level.BODY)
    }
}
