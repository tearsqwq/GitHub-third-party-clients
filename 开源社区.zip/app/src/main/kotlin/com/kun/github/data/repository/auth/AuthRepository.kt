package com.kun.github.data.repository.auth

import com.kun.github.config.GitHubConfig
import com.kun.github.data.local.preferences.AuthPreferences
import com.kun.github.data.remote.api.GithubApi
import com.kun.github.data.remote.client.GithubApiClient
import com.kun.github.data.remote.dto.TokenRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * 认证数据仓库
 * 
 * 职责：
 * - 管理 OAuth Token 的存储和获取
 * - 处理授权码交换 Token 的网络请求
 * - 提供登出功能
 * 
 * 优化点：
 * - 统一错误处理
 * - 使用 Flow 提供 Token 状态流
 * - 清理缓存客户端资源
 */
class AuthRepository(
    private val authPreferences: AuthPreferences,
    private val oauthApi: GithubApi = GithubApiClient.oauthApi
) {
    // ==================== Token 流 ====================
    
    /**
     * Token 状态流
     * 用于监听登录状态变化
     */
    val tokenFlow: Flow<String?> = authPreferences.tokenFlow

    // ==================== OAuth 认证 ====================
    
    /**
     * 使用授权码交换 Token
     * 
     * 流程：
     * 1. 调用 GitHub OAuth API
     * 2. 保存 Token 到本地存储
     * 
     * @param code OAuth 授权码
     * @return Result<String> 成功返回 Token，失败返回错误
     */
    suspend fun exchangeCode(code: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val response = oauthApi.exchangeToken(
                TokenRequest(
                    client_id = GitHubConfig.CLIENT_ID,
                    client_secret = GitHubConfig.CLIENT_SECRET,
                    code = code,
                    redirect_uri = GitHubConfig.REDIRECT_URI
                )
            )
            
            // 保存 Token
            authPreferences.saveToken(response.accessToken)
            Result.success(response.accessToken)
            
        } catch (e: UnknownHostException) {
            Result.failure(IOException("网络连接失败，请检查网络设置", e))
        } catch (e: SocketTimeoutException) {
            Result.failure(IOException("连接超时，请稍后重试", e))
        } catch (e: retrofit2.HttpException) {
            val message = parseAuthError(e.code(), e.message())
            Result.failure(IOException(message, e))
        } catch (e: Exception) {
            Result.failure(IOException("认证失败: ${e.message}", e))
        }
    }
    
    /**
     * 解析认证错误
     * 
     * @param code HTTP 状态码
     * @param message 错误消息
     * @return 用户友好的错误消息
     */
    private fun parseAuthError(code: Int, message: String?): String {
        return when (code) {
            401 -> "认证失败，客户端密钥无效"
            403 -> "访问被拒绝"
            404 -> "授权码无效或已过期"
            in 500..599 -> "GitHub 服务器错误，请稍后重试"
            else -> "认证失败: ${message ?: "Unknown error"}"
        }
    }

    // ==================== 登出 ====================
    
    /**
     * 退出登录
     * 
     * 流程：
     * 1. 获取当前 Token
     * 2. 清除缓存的 API 客户端
     * 3. 清除本地存储的 Token
     */
    suspend fun logout() {
        // 清除缓存的 API 客户端
        val currentToken = authPreferences.tokenFlow.first()
        currentToken?.let { token ->
            GithubApiClient.clearCachedClient(token)
        }
        
        // 清除 Token
        authPreferences.clearToken()
    }
    
    /**
     * 检查是否已登录
     */
    suspend fun isLoggedIn(): Boolean {
        return authPreferences.tokenFlow.first() != null
    }
}
