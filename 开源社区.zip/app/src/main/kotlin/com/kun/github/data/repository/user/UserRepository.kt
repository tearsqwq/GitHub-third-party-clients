package com.kun.github.data.repository.user

import android.util.Base64
import com.kun.github.data.model.GithubPages
import com.kun.github.data.model.GithubRepo
import com.kun.github.data.model.GithubUser
import com.kun.github.data.model.RepoContent
import com.kun.github.data.model.SearchRepositoriesResponse
import com.kun.github.data.model.SearchUsersResponse
import com.kun.github.data.remote.api.GithubApi
import com.kun.github.data.remote.client.GithubApiClient
import com.kun.github.data.remote.dto.CreateFileRequest
import com.kun.github.data.remote.dto.CreateRepoRequest
import com.kun.github.data.remote.dto.PagesDeploymentRequest
import com.kun.github.data.remote.dto.UpdateFileRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class UserRepository(private val cacheDir: File? = null) {

    private fun getApi(token: String): GithubApi {
        return GithubApiClient.createAuthenticatedApi(token, cacheDir)
    }

    private suspend fun <T> safeApiCall(
        call: suspend () -> T
    ): Result<T> = withContext(Dispatchers.IO) {
        try {
            Result.success(call())
        } catch (e: UnknownHostException) {
            Result.failure(IOException("网络连接失败，请检查网络设置", e))
        } catch (e: SocketTimeoutException) {
            Result.failure(IOException("连接超时，请稍后重试", e))
        } catch (e: retrofit2.HttpException) {
            // 尝试解析错误响应体获取更详细的错误信息
            val errorBody = e.response()?.errorBody()?.string()
            val errorMessage = parseErrorMessage(errorBody, e.code())
            Result.failure(IOException(errorMessage, e))
        } catch (e: Exception) {
            Result.failure(IOException("发生错误: ${e.message}", e))
        }
    }

    /**
     * 解析 GitHub API 错误响应，提取友好的错误信息
     */
    private fun parseErrorMessage(errorBody: String?, httpCode: Int): String {
        // 首先根据 HTTP 状态码返回基础错误信息
        val baseMessage = when (httpCode) {
            401 -> "认证失败，请重新登录"
            403 -> "访问被拒绝，可能达到 API 限制或无操作权限"
            404 -> "请求的资源不存在"
            422 -> "请求参数错误"
            in 500..599 -> "服务器错误，请稍后重试"
            else -> "请求失败"
        }

        // 尝试从错误响应体中提取更详细的信息
        if (!errorBody.isNullOrBlank()) {
            try {
                val json = Json.parseToJsonElement(errorBody).jsonObject
                // GitHub API 通常在 message 字段中返回错误信息
                val apiMessage = json["message"]?.jsonPrimitive?.content
                if (!apiMessage.isNullOrBlank()) {
                    // 如果 API 返回了具体错误，结合状态码和错误信息
                    return when {
                        apiMessage.contains("API rate limit") -> "API 调用次数已达上限，请稍后再试"
                        apiMessage.contains("Not Found") -> "仓库不存在或已被删除"
                        apiMessage.contains("Bad credentials") -> "登录凭证无效，请重新登录"
                        apiMessage.contains("delete") && apiMessage.contains("admin") -> "没有删除权限，请检查 Token 权限设置"
                        else -> apiMessage
                    }
                }
            } catch (_: Exception) {
                // 解析失败，返回基础错误信息
            }
        }

        return baseMessage
    }

    suspend fun getUser(token: String): Result<GithubUser> {
        return safeApiCall { getApi(token).getUser() }
    }

    suspend fun getUser(token: String, username: String): Result<GithubUser> {
        return safeApiCall { getApi(token).getUser(username) }
    }

    suspend fun getRepos(token: String): Result<List<GithubRepo>> {
        return safeApiCall { getApi(token).getRepos() }
    }

    suspend fun getUserRepos(token: String, username: String): Result<List<GithubRepo>> {
        return safeApiCall { getApi(token).getUserRepos(username) }
    }

    suspend fun getStarredRepos(token: String): Result<List<GithubRepo>> {
        return safeApiCall { getApi(token).getStarredRepos() }
    }

    suspend fun starRepo(token: String, owner: String, repo: String): Result<Boolean> {
        return safeApiCall {
            getApi(token).starRepo(owner, repo)
            true
        }
    }

    suspend fun unstarRepo(token: String, owner: String, repo: String): Result<Boolean> {
        return safeApiCall {
            getApi(token).unstarRepo(owner, repo)
            true
        }
    }

    suspend fun checkIfStarred(token: String, owner: String, repo: String): Result<Boolean> {
        return safeApiCall {
            val response = getApi(token).checkIfStarred(owner, repo)
            response.isSuccessful
        }
    }

    suspend fun createRepo(token: String, name: String, description: String?): Result<GithubRepo> {
        return safeApiCall {
            getApi(token).createRepo(CreateRepoRequest(name = name, description = description))
        }
    }

    suspend fun getRepoContents(
        token: String,
        owner: String,
        repo: String,
        path: String
    ): Result<List<RepoContent>> {
        return safeApiCall {
            val contents = if (path.isEmpty()) {
                getApi(token).getRepoRootContents(owner, repo)
            } else {
                getApi(token).getRepoContents(owner, repo, path)
            }
            contents.sortedWith(compareBy({ it.type != "dir" }, { it.name }))
        }
    }

    suspend fun getReadme(
        token: String,
        owner: String,
        repo: String
    ): Result<String> {
        return safeApiCall {
            getApi(token).getReadme(owner, repo).string()
        }
    }

    suspend fun getFileContent(
        token: String,
        owner: String,
        repo: String,
        path: String
    ): Result<Pair<String, String>> {
        return safeApiCall {
            val api = getApi(token)
            val fileInfo = api.getFileContent(owner, repo, path)
            val sha = fileInfo.sha ?: ""
            val responseBody = api.getFileRawContent(owner, repo, path)
            val rawContent = responseBody.string()
            Pair(rawContent, sha)
        }
    }

    /**
     * 获取文件的原始 Base64 编码内容（用于重命名二进制文件如图片）
     */
    suspend fun getFileContentBase64(
        token: String,
        owner: String,
        repo: String,
        path: String
    ): Result<Pair<String, String>> {
        return safeApiCall {
            val api = getApi(token)
            val fileInfo = api.getFileContent(owner, repo, path)
            val sha = fileInfo.sha ?: ""
            val responseBody = api.getFileRawContent(owner, repo, path)
            val bytes = responseBody.bytes()
            val base64Content = Base64.encodeToString(bytes, Base64.NO_WRAP)
            Pair(base64Content, sha)
        }
    }

    suspend fun createFile(
        token: String,
        owner: String,
        repo: String,
        path: String,
        content: String,
        message: String = "Create $path"
    ): Result<Unit> {
        return safeApiCall {
            val encodedContent = Base64.encodeToString(content.toByteArray(), Base64.NO_WRAP)
            getApi(token).createFile(owner, repo, path, CreateFileRequest(message, encodedContent))
        }
    }

    /**
     * 创建文件（内容已经是 Base64 编码，用于上传图片等二进制文件）
     */
    suspend fun createFileWithBase64(
        token: String,
        owner: String,
        repo: String,
        path: String,
        base64Content: String,
        message: String = "Upload $path"
    ): Result<Unit> {
        return safeApiCall {
            getApi(token).createFile(owner, repo, path, CreateFileRequest(message, base64Content))
        }
    }

    suspend fun updateFile(
        token: String,
        owner: String,
        repo: String,
        path: String,
        content: String,
        sha: String,
        message: String = "Update $path"
    ): Result<Unit> {
        return safeApiCall {
            val encodedContent = Base64.encodeToString(content.toByteArray(), Base64.NO_WRAP)
            getApi(token).updateFile(owner, repo, path, UpdateFileRequest(message, encodedContent, sha))
        }
    }

    suspend fun createFolder(
        token: String,
        owner: String,
        repo: String,
        path: String,
        message: String = "Create $path"
    ): Result<Unit> {
        return safeApiCall {
            val folderPath = if (path.endsWith("/")) path else "$path/"
            val placeholderFile = "${folderPath}.gitkeep"
            val encodedContent = Base64.encodeToString("".toByteArray(), Base64.NO_WRAP)
            getApi(token).createFile(owner, repo, placeholderFile, CreateFileRequest(message, encodedContent))
        }
    }

    // ============ GitHub Pages 部署 ============

    /**
     * 获取仓库的 GitHub Pages 状态
     * 返回 null 表示未启用，非 null 表示已启用
     */
    suspend fun getPagesInfo(
        token: String,
        owner: String,
        repo: String
    ): Result<GithubPages?> {
        return withContext(Dispatchers.IO) {
            try {
                val response = getApi(token).getPagesInfo(owner, repo)
                val json = response.string()
                val jsonObj = Json.parseToJsonElement(json).jsonObject
                val htmlUrl = jsonObj["html_url"]?.jsonPrimitive?.content
                val status = jsonObj["status"]?.jsonPrimitive?.content
                val sourceObj = jsonObj["source"]?.jsonObject
                val sourceBranch = sourceObj?.get("branch")?.jsonPrimitive?.content ?: "main"
                val sourcePath = sourceObj?.get("path")?.jsonPrimitive?.content ?: "/"
                Result.success(GithubPages(htmlUrl = htmlUrl, status = status, source = sourceObj?.let {
                    com.kun.github.data.remote.dto.PagesSource(branch = sourceBranch, path = sourcePath)
                }))
            } catch (e: retrofit2.HttpException) {
                if (e.code() == 404) {
                    Result.success(null) // Pages 未启用
                } else {
                    Result.failure(IOException("获取 Pages 信息失败: ${e.message()}", e))
                }
            } catch (e: Exception) {
                Result.failure(IOException("获取 Pages 信息失败: ${e.message}", e))
            }
        }
    }

    /**
     * 启用 GitHub Pages 部署
     */
    suspend fun deployPages(
        token: String,
        owner: String,
        repo: String,
        branch: String = "main"
    ): Result<Unit> {
        return withContext(Dispatchers.IO) {
            try {
                val api = getApi(token)
                // 先尝试启用 Pages
                try {
                    api.enablePages(
                        owner, repo,
                        PagesDeploymentRequest(
                            source = com.kun.github.data.remote.dto.PagesSource(
                                branch = branch,
                                path = "/"
                            )
                        )
                    )
                } catch (e: retrofit2.HttpException) {
                    // 如果已经启用，忽略错误
                    if (e.code() != 409 && e.code() != 400) {
                        throw e
                    }
                }
                // 触发构建
                try {
                    api.requestPagesBuild(owner, repo)
                } catch (_: Exception) {
                    // 忽略构建请求错误
                }
                Result.success(Unit)
            } catch (e: retrofit2.HttpException) {
                val message = when (e.code()) {
                    403 -> "没有权限部署此仓库"
                    404 -> "仓库不存在"
                    422 -> "仓库未满足部署条件（需要包含内容）"
                    else -> "部署失败: ${e.message()}"
                }
                Result.failure(IOException(message, e))
            } catch (e: Exception) {
                Result.failure(IOException("部署失败: ${e.message}", e))
            }
        }
    }

    suspend fun forkRepo(token: String, owner: String, repo: String): Result<Unit> {
        return safeApiCall {
            getApi(token).forkRepo(owner, repo)
        }
    }

    suspend fun getBranches(token: String, owner: String, repo: String): Result<List<String>> {
        return safeApiCall {
            val response = getApi(token).getBranches(owner, repo)
            val json = Json.parseToJsonElement(response.string()) as JsonArray
            json.map { it.jsonObject["name"]?.jsonPrimitive?.content ?: "" }
        }
    }

    suspend fun getTags(token: String, owner: String, repo: String): Result<List<String>> {
        return safeApiCall {
            val response = getApi(token).getTags(owner, repo)
            val json = Json.parseToJsonElement(response.string()) as JsonArray
            json.map { it.jsonObject["name"]?.jsonPrimitive?.content ?: "" }
        }
    }

    fun getZipDownloadUrl(owner: String, repo: String, branch: String = "main"): String {
        return "https://github.com/$owner/$repo/archive/refs/heads/$branch.zip"
    }

    suspend fun deleteRepo(token: String, owner: String, repo: String): Result<Unit> {
        return withContext(Dispatchers.IO) {
            try {
                val response = getApi(token).deleteRepo(owner, repo)
                if (response.isSuccessful) {
                    Result.success(Unit)
                } else {
                    // 解析错误响应
                    val errorBody = response.errorBody()?.string()
                    val errorMessage = parseErrorMessage(errorBody, response.code())
                    Result.failure(IOException(errorMessage))
                }
            } catch (e: UnknownHostException) {
                Result.failure(IOException("网络连接失败，请检查网络设置", e))
            } catch (e: SocketTimeoutException) {
                Result.failure(IOException("连接超时，请稍后重试", e))
            } catch (e: retrofit2.HttpException) {
                val errorBody = e.response()?.errorBody()?.string()
                val errorMessage = parseErrorMessage(errorBody, e.code())
                Result.failure(IOException(errorMessage, e))
            } catch (e: Exception) {
                Result.failure(IOException("删除仓库失败: ${e.message}", e))
            }
        }
    }

    suspend fun updateRepo(
        token: String,
        owner: String,
        repo: String,
        request: com.kun.github.data.remote.dto.UpdateRepoRequest
    ): Result<GithubRepo> {
        return safeApiCall {
            getApi(token).updateRepo(owner, repo, request)
        }
    }

    suspend fun deleteFile(token: String, owner: String, repo: String, path: String): Result<Unit> {
        return safeApiCall {
            val api = getApi(token)
            // 先获取文件的 SHA
            val fileInfo = api.getFileContent(owner, repo, path)
            val sha = fileInfo.sha ?: throw Exception("无法获取文件 SHA")
            api.deleteFile(owner, repo, path, com.kun.github.data.remote.dto.DeleteFileRequest(
                message = "Delete $path",
                sha = sha
            ))
        }
    }

    /**
     * 删除文件（已知 SHA，避免重复请求）
     */
    suspend fun deleteFileWithSha(token: String, owner: String, repo: String, path: String, sha: String): Result<Unit> {
        return safeApiCall {
            getApi(token).deleteFile(owner, repo, path, com.kun.github.data.remote.dto.DeleteFileRequest(
                message = "Delete $path",
                sha = sha
            ))
        }
    }

    /**
     * 删除文件夹（递归删除所有内容）
     */
    suspend fun deleteFolder(token: String, owner: String, repo: String, folderPath: String): Result<Unit> {
        return safeApiCall {
            val api = getApi(token)
            val contents = api.getRepoContents(owner, repo, folderPath)
            for (item in contents) {
                if (item.type == "dir") {
                    deleteFolder(token, owner, repo, item.path)
                } else {
                    val fileInfo = api.getFileContent(owner, repo, item.path)
                    val sha = fileInfo.sha ?: throw Exception("无法获取文件 SHA: ${item.path}")
                    api.deleteFile(owner, repo, item.path, com.kun.github.data.remote.dto.DeleteFileRequest(
                        message = "Delete ${item.path}",
                        sha = sha
                    ))
                }
            }
        }
    }

    /**
     * 获取热门仓库（最近30天内创建的最多 star 的仓库）
     * 使用 GitHub Search API 模拟 Trending 功能
     */
    suspend fun getTrendingRepos(token: String): Result<List<GithubRepo>> {
        return safeApiCall {
            val thirtyDaysAgo = java.time.LocalDate.now().minusDays(30)
            val query = "created:>${thirtyDaysAgo}"
            val response = getApi(token).searchRepositories(query)
            response.items
        }
    }

    // ============ 贡献统计 ============

    /**
     * 获取用户的贡献活动统计
     * 通过 Events API 获取用户的 PushEvent 统计每天的提交数
     *
     * @param token 访问令牌
     * @param username GitHub 用户名
     * @param days 获取最近多少天的数据，默认 365 天
     * @return 按日期排序的贡献数据列表
     */
    suspend fun getUserContributions(
        token: String,
        username: String,
        days: Int = 365
    ): Result<List<com.kun.github.presentation.components.ContributionDay>> {
        return withContext(Dispatchers.IO) {
            try {
                val api = getApi(token)
                val endDate = java.time.LocalDate.now()
                val startDate = endDate.minusDays(days.toLong())

                // 获取用户事件（最多获取3页，每页100条）
                val allEvents = mutableListOf<com.kun.github.data.model.GithubEvent>()
                for (page in 1..3) {
                    try {
                        val events = api.getUserEvents(username, page, 100)
                        if (events.isEmpty()) break
                        allEvents.addAll(events)
                    } catch (e: Exception) {
                        break
                    }
                }

                // 统计每天的贡献数
                val contributionMap = mutableMapOf<String, Int>()

                allEvents.forEach { event ->
                    // 只统计 PushEvent
                    if (event.type == "PushEvent") {
                        val eventDate = event.createdAt.substring(0, 10) // yyyy-MM-dd
                        val date = java.time.LocalDate.parse(eventDate)

                        // 只统计指定时间范围内的事件
                        if (!date.isBefore(startDate) && !date.isAfter(endDate)) {
                            // size 表示这次 push 中的 commit 数量
                            val commitCount = event.payload?.size ?: 0
                            contributionMap[eventDate] = contributionMap.getOrDefault(eventDate, 0) + commitCount
                        }
                    }
                }

                // 生成完整的日期列表（包括没有贡献的日期）
                val contributions = mutableListOf<com.kun.github.presentation.components.ContributionDay>()
                var currentDate = startDate
                while (!currentDate.isAfter(endDate)) {
                    val dateStr = currentDate.toString()
                    val count = contributionMap[dateStr] ?: 0
                    contributions.add(com.kun.github.presentation.components.ContributionDay(dateStr, count))
                    currentDate = currentDate.plusDays(1)
                }

                Result.success(contributions)
            } catch (e: UnknownHostException) {
                Result.failure(IOException("网络连接失败，请检查网络设置", e))
            } catch (e: SocketTimeoutException) {
                Result.failure(IOException("连接超时，请稍后重试", e))
            } catch (e: retrofit2.HttpException) {
                val errorBody = e.response()?.errorBody()?.string()
                val errorMessage = parseErrorMessage(errorBody, e.code())
                Result.failure(IOException(errorMessage, e))
            } catch (e: Exception) {
                Result.failure(IOException("获取贡献数据失败: ${e.message}", e))
            }
        }
    }

    // ============ 搜索 ============

    suspend fun searchRepositories(token: String, query: String): Result<SearchRepositoriesResponse> {
        return safeApiCall { getApi(token).searchRepositories(query) }
    }

    suspend fun searchUsers(token: String, query: String): Result<SearchUsersResponse> {
        return safeApiCall { getApi(token).searchUsers(query) }
    }

    // ============ 通知 ============

    /**
     * 获取当前用户的通知列表
     * @param token 访问令牌
     * @param all 如果为 true，返回所有通知包括已读
     * @param page 页码
     * @param perPage 每页数量
     * @return 通知列表
     */
    suspend fun getNotifications(
        token: String,
        all: Boolean = false,
        page: Int = 1,
        perPage: Int = 30
    ): Result<List<com.kun.github.data.model.GithubNotification>> {
        return safeApiCall { getApi(token).getNotifications(all, page, perPage) }
    }

    /**
     * 标记通知为已读
     * @param token 访问令牌
     * @param threadId 通知线程 ID
     */
    suspend fun markNotificationAsRead(token: String, threadId: String): Result<Unit> {
        return safeApiCall {
            val response = getApi(token).markNotificationAsRead(threadId)
            if (response.isSuccessful) {
                Unit
            } else {
                throw IOException("标记通知失败")
            }
        }
    }

    /**
     * 标记所有通知为已读
     */
    suspend fun markAllNotificationsAsRead(token: String): Result<Unit> {
        return safeApiCall {
            val response = getApi(token).markAllNotificationsAsRead()
            if (response.isSuccessful) {
                Unit
            } else {
                throw IOException("标记全部已读失败")
            }
        }
    }

    // ============ Issues ============

    suspend fun getIssues(
        token: String,
        owner: String,
        repo: String,
        state: String = "open",
        page: Int = 1,
        perPage: Int = 30
    ): Result<List<com.kun.github.data.model.GithubIssue>> {
        return safeApiCall { getApi(token).getIssues(owner, repo, state, page, perPage) }
    }

    suspend fun createIssue(
        token: String,
        owner: String,
        repo: String,
        title: String,
        body: String? = null
    ): Result<com.kun.github.data.model.GithubIssue> {
        return safeApiCall { getApi(token).createIssue(owner, repo, com.kun.github.data.remote.api.CreateIssueRequest(title, body)) }
    }

    // ============ Pull Requests ============

    suspend fun getPullRequests(
        token: String,
        owner: String,
        repo: String,
        state: String = "open",
        page: Int = 1,
        perPage: Int = 30
    ): Result<List<com.kun.github.data.model.GithubPullRequest>> {
        return safeApiCall { getApi(token).getPullRequests(owner, repo, state, page, perPage) }
    }

    // ============ Releases ============

    suspend fun getReleases(
        token: String,
        owner: String,
        repo: String,
        page: Int = 1,
        perPage: Int = 30
    ): Result<List<com.kun.github.data.model.GithubRelease>> {
        return safeApiCall { getApi(token).getReleases(owner, repo, page, perPage) }
    }

    // ============ Contributors ============

    suspend fun getContributors(
        token: String,
        owner: String,
        repo: String,
        page: Int = 1,
        perPage: Int = 30
    ): Result<List<com.kun.github.data.model.GithubContributor>> {
        return safeApiCall { getApi(token).getContributors(owner, repo, page, perPage) }
    }
}
