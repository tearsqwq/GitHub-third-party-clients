package com.kun.github.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

/**
 * 贡献日历数据模型
 */
data class ContributionDay(
    val date: String, // yyyy-MM-dd
    val count: Int
)

/**
 * 贡献日历组件 - 显示最近一年的贡献热力图
 *
 * @param contributions 贡献数据列表
 * @param isLoading 是否正在加载
 * @param error 错误信息
 * @param onDayClick 点击某天的回调
 * @param modifier 修饰符
 */
@Composable
fun ContributionCalendar(
    contributions: List<ContributionDay>,
    isLoading: Boolean = false,
    error: String? = null,
    onDayClick: ((ContributionDay) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var selectedDay by remember { mutableStateOf<ContributionDay?>(null) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // 标题
            Text(
                text = "贡献活动",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(16.dp))

            when {
                isLoading -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                error != null -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = error,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }

                else -> {
                    // 生成最近一年的日期网格
                    val calendarData = generateCalendarData(contributions)

                    // 月份标签
                    MonthLabels(calendarData = calendarData)

                    Spacer(modifier = Modifier.height(8.dp))

                    // 热力图网格
                    ContributionGrid(
                        calendarData = calendarData,
                        onDayClick = { day ->
                            selectedDay = day
                            onDayClick?.invoke(day)
                        }
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // 图例
                    ContributionLegend()
                }
            }
        }
    }

    // 点击某天显示的详情对话框
    selectedDay?.let { day ->
        ContributionDayDialog(
            day = day,
            onDismiss = { selectedDay = null }
        )
    }
}

/**
 * 月份标签
 */
@Composable
private fun MonthLabels(calendarData: List<CalendarWeek>) {
    val formatter = DateTimeFormatter.ofPattern("MM月")
    val months = mutableSetOf<String>()
    val monthPositions = mutableListOf<Pair<String, Int>>()

    calendarData.forEachIndexed { index, week ->
        week.days.firstOrNull()?.let { day ->
            val monthLabel = day.date.format(formatter)
            if (months.add(monthLabel)) {
                monthPositions.add(monthLabel to index)
            }
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 28.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        monthPositions.forEach { (month, _) ->
            Text(
                text = month,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.width(28.dp)
            )
        }
    }
}

/**
 * 贡献网格 - 按周排列
 */
@Composable
private fun ContributionGrid(
    calendarData: List<CalendarWeek>,
    onDayClick: (ContributionDay) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        // 星期标签
        WeekdayLabels()

        // 贡献格子 - 使用水平滚动
        androidx.compose.foundation.lazy.LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            items(calendarData.size) { index ->
                val week = calendarData[index]
                Column(
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    week.days.forEach { day ->
                        ContributionCell(
                            day = day,
                            onClick = { onDayClick(day) }
                        )
                    }
                }
            }
        }
    }
}

/**
 * 星期标签 (一、三、五)
 */
@Composable
private fun WeekdayLabels() {
    Column(
        verticalArrangement = Arrangement.spacedBy(3.dp),
        modifier = Modifier.padding(end = 6.dp)
    ) {
        listOf("一", "", "三", "", "五", "", "日").forEach { label ->
            Box(
                modifier = Modifier.size(12.dp),
                contentAlignment = Alignment.Center
            ) {
                if (label.isNotEmpty()) {
                    Text(
                        text = label,
                        fontSize = 9.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                }
            }
        }
    }
}

/**
 * 单个贡献格子
 */
@Composable
private fun ContributionCell(
    day: ContributionDay,
    onClick: () -> Unit
) {
    val backgroundColor = getContributionColor(day.count)

    Box(
        modifier = Modifier
            .size(12.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(backgroundColor)
            .clickable(onClick = onClick)
    )
}

/**
 * 获取贡献颜色
 * 颜色等级：0次(浅灰)、1-3次(浅绿)、4-6次(中绿)、7-9次(深绿)、10+(最深绿)
 */
@Composable
private fun getContributionColor(count: Int): Color {
    return when {
        count == 0 -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        count in 1..3 -> Color(0xFF9BE9A8) // 浅绿
        count in 4..6 -> Color(0xFF40C463) // 中绿
        count in 7..9 -> Color(0xFF30A14E) // 深绿
        else -> Color(0xFF216E39) // 最深绿
    }
}

/**
 * 图例
 */
@Composable
private fun ContributionLegend() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "少",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
        )

        Spacer(modifier = Modifier.width(6.dp))

        // 图例颜色块
        listOf(0, 2, 5, 8, 12).forEach { count ->
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(getContributionColor(count))
            )
            Spacer(modifier = Modifier.width(3.dp))
        }

        Spacer(modifier = Modifier.width(6.dp))

        Text(
            text = "多",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
        )
    }
}

/**
 * 贡献详情对话框
 */
@Composable
private fun ContributionDayDialog(
    day: ContributionDay,
    onDismiss: () -> Unit
) {
    val formatter = DateTimeFormatter.ofPattern("yyyy年MM月dd日")
    val date = LocalDate.parse(day.date)

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = date.format(formatter),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(16.dp))

                val contributionText = when {
                    day.count == 0 -> "没有贡献"
                    day.count == 1 -> "1 次贡献"
                    else -> "${day.count} 次贡献"
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(getContributionColor(day.count))
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = contributionText,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "关闭",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.clickable(onClick = onDismiss)
                )
            }
        }
    }
}

/**
 * 日历周数据
 */
private data class CalendarWeek(
    val days: List<ContributionDay>
)

/**
 * 生成日历数据 - 最近一年的数据，按周组织
 */
private fun generateCalendarData(contributions: List<ContributionDay>): List<CalendarWeek> {
    val endDate = LocalDate.now()
    val startDate = endDate.minusDays(365)

    // 创建日期到贡献数的映射
    val contributionMap = contributions.associateBy(
        { it.date },
        { it.count }
    )

    // 生成所有日期
    val allDays = mutableListOf<ContributionDay>()
    var currentDate = startDate

    while (!currentDate.isAfter(endDate)) {
        val dateStr = currentDate.toString()
        val count = contributionMap[dateStr] ?: 0
        allDays.add(ContributionDay(dateStr, count))
        currentDate = currentDate.plusDays(1)
    }

    // 补齐前面的日期，使第一天是周一
    val firstDay = LocalDate.parse(allDays.first().date)
    val dayOfWeek = firstDay.dayOfWeek.value // 1=周一, 7=周日
    val daysToAdd = dayOfWeek - 1

    repeat(daysToAdd) {
        allDays.add(0, ContributionDay(
            firstDay.minusDays(it + 1L).toString(),
            0
        ))
    }

    // 按周分组 (每周7天)
    val weeks = mutableListOf<CalendarWeek>()
    var currentWeek = mutableListOf<ContributionDay>()

    allDays.forEach { day ->
        currentWeek.add(day)
        if (currentWeek.size == 7) {
            weeks.add(CalendarWeek(currentWeek.toList()))
            currentWeek = mutableListOf()
        }
    }

    // 处理剩余的天数
    if (currentWeek.isNotEmpty()) {
        // 补齐到7天
        while (currentWeek.size < 7) {
            currentWeek.add(ContributionDay("", 0))
        }
        weeks.add(CalendarWeek(currentWeek.toList()))
    }

    return weeks
}

/**
 * 生成模拟贡献数据（用于测试）
 */
fun generateMockContributions(): List<ContributionDay> {
    val contributions = mutableListOf<ContributionDay>()
    val endDate = LocalDate.now()
    val startDate = endDate.minusDays(365)

    var currentDate = startDate
    while (!currentDate.isAfter(endDate)) {
        // 随机生成贡献数，周末概率更高
        val isWeekend = currentDate.dayOfWeek == DayOfWeek.SATURDAY ||
                currentDate.dayOfWeek == DayOfWeek.SUNDAY

        val count = when {
            Math.random() < 0.4 -> 0 // 40% 概率无贡献
            isWeekend -> (1..15).random() // 周末贡献多
            else -> (1..8).random() // 工作日贡献少
        }

        contributions.add(ContributionDay(currentDate.toString(), count))
        currentDate = currentDate.plusDays(1)
    }

    return contributions
}
