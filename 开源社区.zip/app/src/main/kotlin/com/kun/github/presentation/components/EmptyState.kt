package com.kun.github.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kun.github.presentation.settings.strings

/**
 * 空状态组件
 *
 * @param icon 图标
 * @param title 标题
 * @param description 描述文字
 * @param actionText 操作按钮文字（可选）
 * @param onActionClick 操作按钮点击回调（可选）
 * @param secondaryActionText 次要操作按钮文字（可选）
 * @param onSecondaryActionClick 次要操作按钮点击回调（可选）
 */
@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    description: String,
    actionText: String? = null,
    onActionClick: (() -> Unit)? = null,
    secondaryActionText: String? = null,
    onSecondaryActionClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    // 在 Composable 上下文中提前读取颜色
    val primaryColor = MaterialTheme.colorScheme.primary

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // 图标背景装饰
        Box(
            modifier = Modifier
                .size(120.dp)
                .drawBehind {
                    // 绘制渐变背景圆
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                primaryColor.copy(alpha = 0.15f),
                                primaryColor.copy(alpha = 0.05f),
                                Color.Transparent
                            ),
                            center = Offset(size.width / 2, size.height / 2),
                            radius = size.width / 1.5f
                        )
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(56.dp),
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 标题
        Text(
            text = title,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        // 描述
        Text(
            text = description,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            lineHeight = 20.sp,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        // 操作按钮
        if (actionText != null && onActionClick != null) {
            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = onActionClick,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier.fillMaxWidth(0.7f)
            ) {
                Text(
                    text = actionText,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
        }

        // 次要操作按钮
        if (secondaryActionText != null && onSecondaryActionClick != null) {
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onSecondaryActionClick,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(0.7f)
            ) {
                Text(
                    text = secondaryActionText,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
        }
    }
}

/**
 * 仓库列表空状态
 */
@Composable
fun EmptyReposState(
    onCreateClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val s = strings()
    EmptyState(
        icon = Icons.Outlined.FolderOpen,
        title = s.homeEmptyTitle,
        description = s.homeEmptyDesc,
        actionText = s.homeCreateRepo,
        onActionClick = onCreateClick,
        modifier = modifier
    )
}

/**
 * 星标仓库列表空状态
 */
@Composable
fun EmptyStarredState(
    onExploreClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val s = strings()
    EmptyState(
        icon = Icons.Outlined.StarBorder,
        title = s.starsEmptyTitle,
        description = s.starsEmptyDesc,
        actionText = if (onExploreClick != null) "去发现" else null,
        onActionClick = onExploreClick,
        modifier = modifier
    )
}

/**
 * 搜索结果空状态
 */
@Composable
fun EmptySearchState(
    query: String,
    modifier: Modifier = Modifier
) {
    val s = strings()
    EmptyState(
        icon = Icons.Outlined.FolderOpen,
        title = s.networkErrorTitle,
        description = s.networkErrorDesc,
        modifier = modifier
    )
}

/**
 * 网络错误空状态
 */
@Composable
fun NetworkErrorState(
    onRetryClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val s = strings()
    EmptyState(
        icon = Icons.Outlined.FolderOpen,
        title = s.networkErrorTitle,
        description = s.networkErrorDesc,
        actionText = s.retry,
        onActionClick = onRetryClick,
        modifier = modifier
    )
}
