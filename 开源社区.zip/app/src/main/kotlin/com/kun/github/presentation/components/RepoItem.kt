package com.kun.github.presentation.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.ForkLeft
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.kun.github.data.model.GithubRepo
import com.kun.github.presentation.settings.strings
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

// ==================== 语言颜色映射 ====================

/**
 * GitHub 编程语言颜色映射
 * 用于在仓库卡片中显示语言标签的颜色
 */
private val languageColors = mapOf(
    "Kotlin" to Color(0xFFA97BFF),
    "Java" to Color(0xFFB07219),
    "Python" to Color(0xFF3572A5),
    "JavaScript" to Color(0xFFF1E05A),
    "TypeScript" to Color(0xFF3178C6),
    "C" to Color(0xFF555555),
    "C++" to Color(0xFFF34B7D),
    "C#" to Color(0xFF178600),
    "Go" to Color(0xFF00ADD8),
    "Rust" to Color(0xFFDEA584),
    "Swift" to Color(0xFFF05138),
    "Dart" to Color(0xFF00B4AB),
    "Ruby" to Color(0xFF701516),
    "PHP" to Color(0xFF4F5D95),
    "HTML" to Color(0xFFE34C26),
    "CSS" to Color(0xFF563D7C),
    "Shell" to Color(0xFF89E051),
    "Lua" to Color(0xFF000080),
    "Scala" to Color(0xFFDC322F),
    "R" to Color(0xFF198CE7),
    "Objective-C" to Color(0xFF438EFF),
    "Vue" to Color(0xFF41B883),
    "Svelte" to Color(0xFFFF3E00),
    "Groovy" to Color(0xFF4298B8),
    "Jupyter Notebook" to Color(0xFFDA5B0B),
    "Dockerfile" to Color(0xFF384D54),
    "Makefile" to Color(0xFF427819),
    "Nix" to Color(0xFF7E7EFF),
    "Zig" to Color(0xFFEC915C),
    "Elixir" to Color(0xFF6E4A7E),
    "Haskell" to Color(0xFF5E5086),
    "Perl" to Color(0xFF0298C3),
    "Julia" to Color(0xFF9558B2),
    "Vim" to Color(0xFF199F4B),
    "TeX" to Color(0xFF3D6117),
)

/**
 * 获取编程语言对应的颜色
 * 
 * @param language 语言名称
 * @return 对应的颜色，未知语言返回灰色
 */
fun getLanguageColor(language: String): Color {
    return languageColors[language] ?: Color(0xFF8B949E)
}

// ==================== 时间格式化 ====================

/**
 * 格式化时间为相对时间
 * 
 * 示例：
 * - "刚刚"
 * - "5分钟前"
 * - "2小时前"
 * - "3天前"
 * 
 * @param isoTime ISO 8601 格式的时间字符串
 * @param strings 多语言字符串资源
 * @return 格式化后的相对时间字符串
 */
fun formatRelativeTime(isoTime: String?, strings: com.kun.github.presentation.settings.AppStrings): String {
    if (isoTime == null) return ""
    
    return try {
        val formatter = DateTimeFormatter.ISO_DATE_TIME
        val time = Instant.from(formatter.parse(isoTime))
        val now = Instant.now()
        val duration = Duration.between(time, now)
        
        when {
            duration.toMinutes() < 1 -> strings.timeJustNow
            duration.toMinutes() < 60 -> strings.timeMinutesAgo.format(duration.toMinutes())
            duration.toHours() < 24 -> strings.timeHoursAgo.format(duration.toHours())
            duration.toDays() < 7 -> strings.timeDaysAgo.format(duration.toDays())
            duration.toDays() < 30 -> strings.timeWeeksAgo.format(duration.toDays() / 7)
            duration.toDays() < 365 -> strings.timeMonthsAgo.format(duration.toDays() / 30)
            else -> strings.timeYearsAgo.format(duration.toDays() / 365)
        }
    } catch (e: Exception) {
        ""
    }
}

/**
 * 简化 License 名称显示
 * 
 * @param licenseName 原始 License 名称
 * @return 简化后的名称
 */
fun formatLicense(licenseName: String?): String {
    return when {
        licenseName == null -> ""
        licenseName.contains("MIT") -> "MIT"
        licenseName.contains("Apache") -> "Apache"
        licenseName.contains("GPL") -> "GPL"
        licenseName.contains("BSD") -> "BSD"
        licenseName.contains("Mozilla") -> "MPL"
        else -> licenseName.take(10)
    }
}

// ==================== 仓库卡片组件 ====================

/**
 * 仓库列表项组件
 * 
 * 功能：
 * - 显示仓库基本信息（名称、描述、语言、星标数等）
 * - 支持点击和长按事件
 * - 支持星标操作
 * - 显示相对更新时间
 * 
 * @param repo 仓库数据
 * @param modifier 修饰符
 * @param onClick 点击回调
 * @param onLongClick 长按回调
 * @param isStarred 是否已星标
 * @param onStarClick 星标按钮点击回调
 * @param onOwnerClick 所有者点击回调
 */
@Composable
fun RepoItem(
    repo: GithubRepo,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {},
    onLongClick: () -> Unit = {},
    isStarred: Boolean = false,
    onStarClick: (() -> Unit)? = null,
    onOwnerClick: (() -> Unit)? = null
) {
    val s = strings()
    
    // 入场动画
    val interactionScale by animateFloatAsState(
        targetValue = 1f,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMedium),
        label = "itemScale"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .scale(interactionScale)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // 顶部：语言标签 + 更新时间
            RepoItemHeader(repo = repo, strings = s)
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // 中部：仓库名 + Star 按钮
            RepoItemTitle(
                repo = repo,
                isStarred = isStarred,
                onStarClick = onStarClick
            )
            
            // 描述（如果有）
            repo.description?.let { desc ->
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = desc,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // 底部：所有者 + Fork + License
            RepoItemFooter(
                repo = repo,
                strings = s,
                onOwnerClick = onOwnerClick
            )
        }
    }
}

/**
 * 仓库卡片头部：语言标签 + 更新时间
 */
@Composable
private fun RepoItemHeader(
    repo: GithubRepo,
    strings: com.kun.github.presentation.settings.AppStrings
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // 语言标签
        if (repo.language != null) {
            val langColor = getLanguageColor(repo.language)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(langColor)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = repo.language,
                    fontSize = 12.sp,
                    color = langColor,
                    fontWeight = FontWeight.Medium
                )
            }
        } else {
            Spacer(modifier = Modifier)
        }
        
        // 更新时间
        val relativeTime = formatRelativeTime(repo.pushedAt ?: repo.updatedAt, strings)
        if (relativeTime.isNotEmpty()) {
            Text(
                text = strings.repoUpdatedAt.format(relativeTime),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
        }
    }
}

/**
 * 仓库卡片标题：仓库名 + Star 按钮
 */
@Composable
private fun RepoItemTitle(
    repo: GithubRepo,
    isStarred: Boolean,
    onStarClick: (() -> Unit)?
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // 仓库名
        Text(
            text = repo.name,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        
        Spacer(modifier = Modifier.width(8.dp))
        
        // Star 按钮
        if (onStarClick != null) {
            IconButton(
                onClick = onStarClick,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = if (isStarred) Icons.Filled.Star else Icons.Outlined.Star,
                    contentDescription = if (isStarred) "取消星标" else "添加星标",
                    tint = if (isStarred) Color(0xFFFFC107) 
                           else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.size(20.dp)
                )
            }
        } else {
            // 只显示 Star 数（无星标按钮时）
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Star,
                    contentDescription = null,
                    tint = Color(0xFFFFB800),
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = formatCount(repo.stars),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

/**
 * 仓库卡片底部：所有者 + Fork + License + 私有标签
 */
@Composable
private fun RepoItemFooter(
    repo: GithubRepo,
    strings: com.kun.github.presentation.settings.AppStrings,
    onOwnerClick: (() -> Unit)?
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // 左侧：所有者头像 + 名称
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = if (onOwnerClick != null) Modifier.clickable(onClick = onOwnerClick) 
                       else Modifier
        ) {
            AsyncImage(
                model = repo.owner.avatarUrl,
                contentDescription = "Owner",
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Text(
                text = repo.owner.login,
                fontSize = 12.sp,
                color = if (onOwnerClick != null) MaterialTheme.colorScheme.primary
                       else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // 右侧：Fork 数 + License + 私有标签
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Fork
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.ForkLeft,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = formatCount(repo.forks),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
            
            // License
            val licenseText = formatLicense(repo.license?.name)
            if (licenseText.isNotEmpty()) {
                Text(
                    text = "·  $licenseText",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
            
            // 私有标签
            if (repo.private) {
                Box(
                    modifier = Modifier
                        .background(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = strings.repoPrivate,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

// ==================== 工具函数 ====================

/**
 * 格式化数字（大数简化显示）
 * 
 * 示例：
 * - 1234 -> "1.2k"
 * - 1234567 -> "1.2M"
 * 
 * @param count 原始数字
 * @return 格式化后的字符串
 */
private fun formatCount(count: Int): String {
    return when {
        count >= 1000000 -> String.format("%.1fM", count / 1000000.0)
        count >= 1000 -> String.format("%.1fk", count / 1000.0)
        else -> count.toString()
    }
}
