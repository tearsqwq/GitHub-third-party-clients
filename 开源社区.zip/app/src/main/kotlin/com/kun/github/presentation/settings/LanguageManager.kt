package com.kun.github.presentation.settings

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.LocaleList
import java.util.Locale

/**
 * 应用语言管理器
 */
object LanguageManager {
    
    private const val PREFS_NAME = "app_settings"
    private const val KEY_LANGUAGE = "app_language"
    
    /**
     * 支持的语言
     */
    enum class AppLanguage(val code: String, val displayName: String) {
        SYSTEM("system", "跟随系统"),
        CHINESE("zh", "简体中文"),
        ENGLISH("en", "English");
        
        companion object {
            fun fromCode(code: String): AppLanguage {
                return entries.find { it.code == code } ?: SYSTEM
            }
        }
    }
    
    /**
     * 获取当前设置的语言
     */
    fun getCurrentLanguage(context: Context): AppLanguage {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val code = prefs.getString(KEY_LANGUAGE, AppLanguage.SYSTEM.code)
        return AppLanguage.fromCode(code ?: AppLanguage.SYSTEM.code)
    }
    
    /**
     * 设置应用语言
     */
    fun setLanguage(context: Context, language: AppLanguage) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_LANGUAGE, language.code).apply()
        
        // 应用语言更改
        applyLanguage(context, language)
    }
    
    /**
     * 应用语言到上下文
     */
    fun applyLanguage(context: Context, language: AppLanguage? = null): Context {
        val lang = language ?: getCurrentLanguage(context)
        
        val locale = when (lang) {
            AppLanguage.SYSTEM -> getSystemLocale()
            AppLanguage.CHINESE -> Locale.CHINESE
            AppLanguage.ENGLISH -> Locale.ENGLISH
        }
        
        return updateLocale(context, locale)
    }
    
    /**
     * 获取系统语言
     */
    private fun getSystemLocale(): Locale {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            LocaleList.getDefault()[0]
        } else {
            Locale.getDefault()
        }
    }
    
    /**
     * 更新上下文语言
     */
    private fun updateLocale(context: Context, locale: Locale): Context {
        Locale.setDefault(locale)
        
        val config = Configuration(context.resources.configuration)
        
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            config.setLocales(LocaleList(locale))
            context.createConfigurationContext(config)
        } else {
            config.setLocale(locale)
            context.createConfigurationContext(config)
        }
    }

    /**
     * 只更新 Activity 的 resources 语言配置，不创建新 Context。
     * 这样不会破坏 enableEdgeToEdge 的窗口配置。
     */
    fun applyLanguageToResources(activity: android.app.Activity) {
        val lang = getCurrentLanguage(activity)
        val locale = when (lang) {
            AppLanguage.SYSTEM -> getSystemLocale()
            AppLanguage.CHINESE -> Locale.CHINESE
            AppLanguage.ENGLISH -> Locale.ENGLISH
        }

        Locale.setDefault(locale)

        val config = Configuration(activity.resources.configuration)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            config.setLocales(LocaleList(locale))
        } else {
            config.setLocale(locale)
        }
        activity.resources.updateConfiguration(config, activity.resources.displayMetrics)
    }
    
    /**
     * 获取语言显示名称
     */
    fun getLanguageDisplayName(context: Context): String {
        return getCurrentLanguage(context).displayName
    }
}
