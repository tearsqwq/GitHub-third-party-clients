package com.kun.github.presentation.theme

import androidx.compose.ui.graphics.Color

// ===== 黑白主色调 =====
val AccentBlack = Color(0xFF000000)
val AccentWhite = Color(0xFFFFFFFF)

// ===== 亮色模式 =====
val Light_Background = Color(0xFFFFFFFF)
val Light_Surface = Color(0xFFF8F8F8)
val Light_SurfaceVariant = Color(0xFFEEEEEE)
val Light_Border = Color(0xFFE0E0E0)
val Light_OnBackground = Color(0xFF1A1A1A)
val Light_OnSurface = Color(0xFF1A1A1A)
val Light_OnSurfaceVariant = Color(0xFF666666)
val Light_Primary = Color(0xFF000000)
val Light_OnPrimary = Color(0xFFFFFFFF)
val Light_Error = Color(0xFFD32F2F)
val Light_OnError = Color(0xFFFFFFFF)

// ===== 暗色模式 =====
val Dark_Background = Color(0xFF000000)
val Dark_Surface = Color(0xFF161616)
val Dark_SurfaceVariant = Color(0xFF222222)
val Dark_Border = Color(0xFF2A2A2A)
val Dark_OnBackground = Color(0xFFF0F0F0)
val Dark_OnSurface = Color(0xFFF0F0F0)
val Dark_OnSurfaceVariant = Color(0xFF888888)
val Dark_Primary = Color(0xFFFFFFFF)
val Dark_OnPrimary = Color(0xFF000000)
val Dark_Error = Color(0xFFEF5350)
val Dark_OnError = Color(0xFF000000)
