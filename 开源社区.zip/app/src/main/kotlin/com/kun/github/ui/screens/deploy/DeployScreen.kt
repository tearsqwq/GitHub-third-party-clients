package com.kun.github.ui.screens.deploy

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.outlined.CloudQueue
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.RocketLaunch
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.kun.github.data.model.GithubPages
import com.kun.github.data.model.GithubRepo
import com.kun.github.data.repository.user.UserRepository
import com.kun.github.presentation.settings.strings
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun DeployScreen(
    modifier: Modifier = Modifier,
    token: String,
    repos: List<GithubRepo>,
    userLogin: String?,
    userRepository: UserRepository,
    onRepoClick: (GithubRepo) -> Unit = {}
) {
    var pagesStatus by remember { mutableStateOf<Map<String, GithubPages?>>(emptyMap()) }
    var loadingRepos by remember { mutableStateOf<Set<String>>(emptySet()) }
    var deployingRepos by remember { mutableStateOf<Set<String>>(emptySet()) }
    var isRefreshing by remember { mutableStateOf(false) }
    var refreshKey by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val s = strings()

    LaunchedEffect(repos, refreshKey) {
        pagesStatus = emptyMap()
        loadingRepos = repos.map { it.fullName }.toSet()
        repos.forEach { repo ->
            scope.launch {
                val result = userRepository.getPagesInfo(token, repo.owner.login, repo.name)
                result.onSuccess { pages ->
                    pagesStatus = pagesStatus + (repo.fullName to pages)
                }
                // 失败也标记为 null（未部署）
                loadingRepos = loadingRepos - repo.fullName
            }
        }
    }

    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh = {
            isRefreshing = true
            refreshKey++
            isRefreshing = false
        }
    ) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 标题区域
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Cloud,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(
                        s.deployTitle,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        s.deploySubtitle,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        // 仓库列表
        if (repos.isEmpty() && loadingRepos.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    s.deployEmptyRepos,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    start = 20.dp,
                    end = 20.dp,
                    bottom = 100.dp
                ),
                modifier = Modifier.weight(1f)
            ) {
                items(repos, key = { it.id }) { repo ->
                    val pages = pagesStatus[repo.fullName]
                    val isLoading = loadingRepos.contains(repo.fullName)
                    val isDeploying = deployingRepos.contains(repo.fullName)
                    val isOwn = userLogin != null && repo.owner.login.equals(userLogin, ignoreCase = true)

                    DeployRepoCard(
                        repo = repo,
                        pages = pages,
                        isLoading = isLoading,
                        isDeploying = isDeploying,
                        isOwn = isOwn,
                        onClick = { onRepoClick(repo) },
                        onDeploy = {
                            scope.launch {
                                deployingRepos = deployingRepos + repo.fullName
                                val result = userRepository.deployPages(token, repo.owner.login, repo.name)
                                result.onSuccess {
                                    Toast.makeText(context, s.deployRequestSent, Toast.LENGTH_SHORT).show()
                                    // 延迟后刷新状态
                                    delay(2000)
                                    val statusResult = userRepository.getPagesInfo(token, repo.owner.login, repo.name)
                                    statusResult.onSuccess { status ->
                                        pagesStatus = pagesStatus + (repo.fullName to status)
                                    }
                                }.onFailure { error ->
                                    Toast.makeText(context, error.message ?: s.deployFailed, Toast.LENGTH_SHORT).show()
                                }
                                deployingRepos = deployingRepos - repo.fullName
                            }
                        },
                        onOpenUrl = { url ->
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                            context.startActivity(intent)
                        }
                    )
                }
            }
        }
    }
    }
}

@Composable
private fun DeployRepoCard(
    repo: GithubRepo,
    pages: GithubPages?,
    isLoading: Boolean,
    isDeploying: Boolean,
    isOwn: Boolean,
    onClick: () -> Unit,
    onDeploy: () -> Unit,
    onOpenUrl: (String) -> Unit
) {
    val s = strings()
    val buttonScale by animateFloatAsState(
        targetValue = if (isDeploying) 0.95f else 1f,
        animationSpec = spring(dampingRatio = 0.8f),
        label = "buttonScale"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // 仓库信息行
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(
                    model = repo.owner.avatarUrl,
                    contentDescription = "Owner",
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = repo.name,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = repo.owner.login,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // 状态指示器
                StatusBadge(
                    isLoading = isLoading,
                    isDeploying = isDeploying,
                    isDeployed = pages != null
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            HorizontalDivider(
                thickness = 0.5.dp,
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 状态内容
            when {
                isLoading || isDeploying -> {
                    LoadingContent()
                }
                pages != null -> {
                    DeployedContent(
                        repo = repo,
                        pages = pages,
                        onOpenUrl = onOpenUrl
                    )
                }
                else -> {
                    NotDeployedContent(
                        isOwn = isOwn,
                        buttonScale = buttonScale,
                        onDeploy = onDeploy
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusBadge(
    isLoading: Boolean,
    isDeploying: Boolean,
    isDeployed: Boolean
) {
    val (backgroundColor, contentColor, icon) = when {
        isLoading || isDeploying -> Triple(
            MaterialTheme.colorScheme.surfaceVariant,
            MaterialTheme.colorScheme.onSurfaceVariant,
            null
        )
        isDeployed -> Triple(
            MaterialTheme.colorScheme.primaryContainer,
            MaterialTheme.colorScheme.onPrimaryContainer,
            Icons.Filled.CheckCircle
        )
        else -> Triple(
            MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
            MaterialTheme.colorScheme.onErrorContainer,
            null
        )
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(backgroundColor)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        if (isLoading || isDeploying) {
            CircularProgressIndicator(
                modifier = Modifier.size(14.dp),
                strokeWidth = 2.dp,
                color = contentColor
            )
        } else if (isDeployed) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = icon!!,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp),
                    tint = contentColor
                )
                Text(
                    text = "已部署",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = contentColor
                )
            }
        } else {
            Text(
                text = "未部署",
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = contentColor
            )
        }
    }
}

@Composable
private fun LoadingContent() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(18.dp),
            strokeWidth = 2.dp,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = "检查部署状态...",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun DeployedContent(
    repo: GithubRepo,
    pages: GithubPages,
    onOpenUrl: (String) -> Unit
) {
    val s = strings()

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = "访问地址",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                text = "${repo.owner.login}.github.io/${repo.name}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        OutlinedButton(
            onClick = {
                val url = pages.htmlUrl ?: "https://${repo.owner.login}.github.io/${repo.name}"
                onOpenUrl(url)
            },
            shape = RoundedCornerShape(10.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            modifier = Modifier.height(32.dp)
        ) {
            Icon(
                imageVector = Icons.Outlined.OpenInNew,
                contentDescription = null,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(s.deployVisit, fontSize = 12.sp)
        }
    }
}

@Composable
private fun NotDeployedContent(
    isOwn: Boolean,
    buttonScale: Float,
    onDeploy: () -> Unit
) {
    val s = strings()

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = if (isOwn) "点击按钮开始部署" else "仅仓库所有者可部署",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
            )
        }

        if (isOwn) {
            Button(
                onClick = onDeploy,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                modifier = Modifier
                    .height(36.dp)
                    .scale(buttonScale)
            ) {
                Icon(
                    imageVector = Icons.Outlined.RocketLaunch,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(s.deployTitle, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}
