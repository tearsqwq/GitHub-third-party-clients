package com.kun.github.ui.screens.detail

import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.InsertDriveFile
import androidx.compose.material.icons.automirrored.outlined.NoteAdd
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.CloudUpload
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.ForkLeft
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.kun.github.R
import com.kun.github.data.model.GithubRepo
import com.kun.github.data.model.RepoContent
import com.kun.github.data.remote.client.GithubApiClient
import com.kun.github.data.repository.user.UserRepository
import com.kun.github.utils.file.FileSizeFormatter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RepoDetailScreen(
    repo: GithubRepo,
    token: String,
    currentUserLogin: String?,
    onBack: () -> Unit,
    userRepository: UserRepository,
    onPreviewFile: (String) -> Unit = {},
    onPreviewImage: (String) -> Unit = {},
    onOwnerClick: (String) -> Unit = {},
    onNavigateToIssues: () -> Unit = {},
    onNavigateToPullRequests: () -> Unit = {},
    onNavigateToReleases: () -> Unit = {},
    onNavigateToContributors: () -> Unit = {},
    cacheDir: File? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var contents by remember { mutableStateOf<List<RepoContent>?>(null) }
    var readmeHtml by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var isReadmeLoading by remember { mutableStateOf(false) }
    var isStarred by remember { mutableStateOf(false) }
    var starCount by remember { mutableStateOf(repo.stars) }

    // 检查星标状态
    LaunchedEffect(repo) {
        userRepository.checkIfStarred(token, repo.owner.login, repo.name).fold(
            onSuccess = { isStarred = it },
            onFailure = {}
        )
    }

    fun toggleStar() {
        scope.launch {
            val result = if (isStarred) {
                userRepository.unstarRepo(token, repo.owner.login, repo.name)
            } else {
                userRepository.starRepo(token, repo.owner.login, repo.name)
            }
            result.fold(
                onSuccess = {
                    isStarred = !isStarred
                    starCount = if (isStarred) starCount + 1 else starCount - 1
                    android.widget.Toast.makeText(
                        context,
                        if (isStarred) "已添加星标" else "已取消星标",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                },
                onFailure = {}
            )
        }
    }
    var currentPath by remember { mutableStateOf("") }
    var pathHistory by rememberSaveable { mutableStateOf(listOf<String>()) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isRefreshing by remember { mutableStateOf(false) }
    val isDark = isSystemInDarkTheme()

    // 在 WebView 更新中使用 isDark，而不是再次调用 isSystemInDarkTheme()

    // 创建文件/文件夹对话框状态
    var showCreateDialog by remember { mutableStateOf(false) }
    var createType by remember { mutableStateOf<CreateType?>(null) }
    var newItemName by remember { mutableStateOf("") }
    var newFileContent by remember { mutableStateOf("") }
    var isCreating by remember { mutableStateOf(false) }

    // 长按上下文菜单状态
    var contextMenuItem by remember { mutableStateOf<RepoContent?>(null) }

    // 文件列表右上角 "+" 按钮菜单状态
    var showFileActionMenu by remember { mutableStateOf(false) }

    // 重命名对话框状态
    var showRenameDialog by remember { mutableStateOf(false) }
    var renameName by remember { mutableStateOf("") }
    var isRenaming by remember { mutableStateOf(false) }
    var renameTargetItem by remember { mutableStateOf<RepoContent?>(null) }

    // 删除对话框状态
    var showDeleteDialog by remember { mutableStateOf(false) }
    var deleteTargetItem by remember { mutableStateOf<RepoContent?>(null) }
    var isDeleting by remember { mutableStateOf(false) }

    // 判断是否为当前用户的仓库
    val isOwnRepo = currentUserLogin != null && repo.owner.login.equals(currentUserLogin, ignoreCase = true)

    fun loadContents(path: String) {
        scope.launch {
            isLoading = true
            errorMessage = null
            try {
                val result = userRepository.getRepoContents(token, repo.owner.login, repo.name, path)
                result.fold(
                    onSuccess = { contents = it },
                    onFailure = { errorMessage = it.message }
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                errorMessage = e.message ?: "加载失败"
            } finally {
                isLoading = false
            }
        }
    }

    fun loadReadme() {
        scope.launch {
            isReadmeLoading = true
            try {
                val result = userRepository.getReadme(token, repo.owner.login, repo.name)
                readmeHtml = result.getOrNull()?.takeIf { it.isNotBlank() }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
            } finally {
                isReadmeLoading = false
            }
        }
    }

    // 上传文件启动器
    val uploadFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            scope.launch {
                try {
                    // 通过 ContentResolver 获取真实文件名
                    var fileName = "uploaded_file"
                    context.contentResolver.query(it, null, null, null, null)?.use { cursor ->
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (cursor.moveToFirst() && nameIndex >= 0) {
                            fileName = cursor.getString(nameIndex)
                        }
                    }
                    // 如果没拿到文件名，尝试从 URI 路径中提取
                    if (fileName == "uploaded_file") {
                        fileName = it.lastPathSegment?.substringAfterLast("/") ?: "uploaded_file"
                    }
                    val inputStream = context.contentResolver.openInputStream(it)
                    val bytes = inputStream?.readBytes() ?: byteArrayOf()
                    val content = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                    val fullPath = if (currentPath.isEmpty()) fileName else "$currentPath/$fileName"
                    val result = userRepository.createFileWithBase64(token, repo.owner.login, repo.name, fullPath, content)
                    result.fold(
                        onSuccess = {
                            // 清除缓存后重新加载，确保能看到新上传的文件
                            GithubApiClient.refreshClient(token, cacheDir)
                            loadContents(currentPath)
                            Toast.makeText(context, "文件上传成功", Toast.LENGTH_SHORT).show()
                        },
                        onFailure = { errorMessage = it.message }
                    )
                } catch (e: Exception) {
                    errorMessage = "上传文件失败: ${e.message}"
                }
            }
        }
    }

    fun createFileOrFolder() {
        scope.launch {
            isCreating = true
            val fullPath = if (currentPath.isEmpty()) newItemName else "$currentPath/$newItemName"

            val result = when (createType) {
                CreateType.FILE -> userRepository.createFile(
                    token, repo.owner.login, repo.name, fullPath, newFileContent
                )
                CreateType.FOLDER -> userRepository.createFolder(
                    token, repo.owner.login, repo.name, fullPath
                )
                else -> null
            }

            isCreating = false
            showCreateDialog = false
            newItemName = ""
            newFileContent = ""

            result?.fold(
                onSuccess = {
                    // 清除缓存后重新加载，确保能看到新创建的文件/文件夹
                    GithubApiClient.refreshClient(token, cacheDir)
                    loadContents(currentPath)
                    val successMessage = if (createType == CreateType.FILE) "文件创建成功" else "文件夹创建成功"
                    Toast.makeText(context, successMessage, Toast.LENGTH_SHORT).show()
                },
                onFailure = { errorMessage = it.message }
            )
        }
    }

    fun renameFile() {
        val item = renameTargetItem ?: return
        if (renameName.isBlank() || renameName == item.name) {
            showRenameDialog = false
            renameTargetItem = null
            return
        }
        scope.launch {
            isRenaming = true
            try {
                val pathParts = item.path.split("/")
                val parentPath = pathParts.dropLast(1).joinToString("/")
                val newPath = if (parentPath.isEmpty()) renameName else "$parentPath/$renameName"
                // 判断是否为二进制文件（图片等），使用 Base64 方式处理
                if (isBinaryFile(item.name)) {
                    val contentResult = userRepository.getFileContentBase64(token, repo.owner.login, repo.name, item.path)
                    contentResult.fold(
                        onSuccess = { (base64Content, sha) ->
                            // 先创建新文件
                            val createResult = userRepository.createFileWithBase64(
                                token, repo.owner.login, repo.name, newPath, base64Content
                            )
                            createResult.fold(
                                onSuccess = {
                                    // 用已知的 SHA 直接删除旧文件，避免重复请求
                                    userRepository.deleteFileWithSha(token, repo.owner.login, repo.name, item.path, sha)
                                    Toast.makeText(context, "重命名成功", Toast.LENGTH_SHORT).show()
                                    GithubApiClient.refreshClient(token, cacheDir)
                                    loadContents(currentPath)
                                },
                                onFailure = { errorMessage = it.message }
                            )
                        },
                        onFailure = { errorMessage = it.message }
                    )
                } else {
                    // 文本文件：获取内容 -> 创建新文件 -> 删除旧文件
                    val contentResult = userRepository.getFileContent(token, repo.owner.login, repo.name, item.path)
                    contentResult.fold(
                        onSuccess = { (content, sha) ->
                            val createResult = userRepository.createFile(
                                token, repo.owner.login, repo.name, newPath, content
                            )
                            createResult.fold(
                                onSuccess = {
                                    // 用已知的 SHA 直接删除旧文件，避免重复请求
                                    userRepository.deleteFileWithSha(token, repo.owner.login, repo.name, item.path, sha)
                                    Toast.makeText(context, "重命名成功", Toast.LENGTH_SHORT).show()
                                    GithubApiClient.refreshClient(token, cacheDir)
                                    loadContents(currentPath)
                                },
                                onFailure = { errorMessage = it.message }
                            )
                        },
                        onFailure = { errorMessage = it.message }
                    )
                }
            } catch (e: Exception) {
                errorMessage = "重命名失败: ${e.message}"
            } finally {
                isRenaming = false
                showRenameDialog = false
                renameTargetItem = null
            }
        }
    }

    fun renameFolder() {
        val item = renameTargetItem ?: return
        if (renameName.isBlank() || renameName == item.name) {
            showRenameDialog = false
            renameTargetItem = null
            return
        }
        scope.launch {
            isRenaming = true
            try {
                val pathParts = item.path.split("/")
                val parentPath = pathParts.dropLast(1).joinToString("/")
                val newPath = if (parentPath.isEmpty()) renameName else "$parentPath/$renameName"

                // 获取文件夹内所有内容
                val folderContentsResult = userRepository.getRepoContents(token, repo.owner.login, repo.name, item.path)
                folderContentsResult.fold(
                    onSuccess = { folderContents ->
                        if (folderContents.isEmpty()) {
                            // 空文件夹：创建新 .gitkeep -> 删除旧 .gitkeep
                            val oldGitkeep = "${item.path}/.gitkeep"
                            val newGitkeep = "$newPath/.gitkeep"
                            val createResult = userRepository.createFile(token, repo.owner.login, repo.name, newGitkeep, "")
                            createResult.fold(
                                onSuccess = {
                                    userRepository.deleteFile(token, repo.owner.login, repo.name, oldGitkeep)
                                    Toast.makeText(context, "重命名成功", Toast.LENGTH_SHORT).show()
                                    GithubApiClient.refreshClient(token, cacheDir)
                                    loadContents(currentPath)
                                },
                                onFailure = { errorMessage = it.message }
                            )
                        } else {
                            // 非空文件夹：逐个复制文件到新路径，然后删除旧文件夹
                            var hasError = false
                            for (subItem in folderContents) {
                                if (hasError) break
                                val subNewPath = subItem.path.replaceFirst(item.path, newPath)
                                if (subItem.type == "file") {
                                    if (isBinaryFile(subItem.name)) {
                                        val subResult = userRepository.getFileContentBase64(token, repo.owner.login, repo.name, subItem.path)
                                        subResult.fold(
                                            onSuccess = { (base64Content, sha) ->
                                                val cResult = userRepository.createFileWithBase64(token, repo.owner.login, repo.name, subNewPath, base64Content)
                                                cResult.fold(
                                                    onSuccess = {
                                                        userRepository.deleteFileWithSha(token, repo.owner.login, repo.name, subItem.path, sha)
                                                    },
                                                    onFailure = { errorMessage = it.message; hasError = true }
                                                )
                                            },
                                            onFailure = { errorMessage = it.message; hasError = true }
                                        )
                                    } else {
                                        val subResult = userRepository.getFileContent(token, repo.owner.login, repo.name, subItem.path)
                                        subResult.fold(
                                            onSuccess = { (content, sha) ->
                                                val cResult = userRepository.createFile(token, repo.owner.login, repo.name, subNewPath, content)
                                                cResult.fold(
                                                    onSuccess = {
                                                        userRepository.deleteFileWithSha(token, repo.owner.login, repo.name, subItem.path, sha)
                                                    },
                                                    onFailure = { errorMessage = it.message; hasError = true }
                                                )
                                            },
                                            onFailure = { errorMessage = it.message; hasError = true }
                                        )
                                    }
                                }
                                // 子文件夹暂不处理（GitHub API 限制，需要递归）
                            }
                            if (!hasError) {
                                Toast.makeText(context, "重命名成功", Toast.LENGTH_SHORT).show()
                                GithubApiClient.refreshClient(token, cacheDir)
                                loadContents(currentPath)
                            }
                        }
                    },
                    onFailure = { errorMessage = it.message }
                )
            } catch (e: Exception) {
                errorMessage = "重命名失败: ${e.message}"
            } finally {
                isRenaming = false
                showRenameDialog = false
                renameTargetItem = null
            }
        }
    }

    fun deleteFile() {
        val item = deleteTargetItem ?: return
        scope.launch {
            isDeleting = true
            try {
                val result = userRepository.deleteFile(token, repo.owner.login, repo.name, item.path)
                isDeleting = false
                showDeleteDialog = false
                deleteTargetItem = null
                result.fold(
                    onSuccess = {
                        GithubApiClient.refreshClient(token, cacheDir)
                        loadContents(currentPath)
                        Toast.makeText(context, "删除成功", Toast.LENGTH_SHORT).show()
                    },
                    onFailure = { errorMessage = it.message }
                )
            } catch (e: Exception) {
                isDeleting = false
                errorMessage = "删除失败: ${e.message}"
            }
        }
    }

    fun deleteFolder() {
        val item = deleteTargetItem ?: return
        scope.launch {
            isDeleting = true
            try {
                val result = userRepository.deleteFolder(token, repo.owner.login, repo.name, item.path)
                isDeleting = false
                showDeleteDialog = false
                deleteTargetItem = null
                result.fold(
                    onSuccess = {
                        GithubApiClient.refreshClient(token, cacheDir)
                        loadContents(currentPath)
                        Toast.makeText(context, "删除成功", Toast.LENGTH_SHORT).show()
                    },
                    onFailure = { errorMessage = it.message }
                )
            } catch (e: Exception) {
                isDeleting = false
                errorMessage = "删除失败: ${e.message}"
            }
        }
    }

    LaunchedEffect(repo.id) {
        // 当仓库变化时重新加载
        loadContents("")
        loadReadme()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            // 带返回按钮和右上角菜单的 TopAppBar
            var showDetailMenu by remember { mutableStateOf(false) }
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = repo.name,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = repo.fullName,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack
                    ) {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_arrow_left),
                            contentDescription = "返回",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                },
                actions = {
                    Box {
                        androidx.compose.material3.Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .clickable { showDetailMenu = true },
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "仓库",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Outlined.ExpandMore,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        DropdownMenu(
                            expanded = showDetailMenu,
                            onDismissRequest = { showDetailMenu = false },
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            shape = RoundedCornerShape(14.dp),
                            shadowElevation = 0.dp,
                            border = null,
                            offset = DpOffset(x = (-8).dp, y = 0.dp)
                        ) {
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Outlined.ErrorOutline,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = "Issues",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Normal,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                },
                                onClick = {
                                    showDetailMenu = false
                                    onNavigateToIssues()
                                },
                                contentPadding = PaddingValues(
                                    start = 14.dp, end = 14.dp, top = 9.dp, bottom = 9.dp
                                ),
                                modifier = Modifier.height(36.dp)
                            )
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Outlined.Code,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = "Pull Requests",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Normal,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                },
                                onClick = {
                                    showDetailMenu = false
                                    onNavigateToPullRequests()
                                },
                                contentPadding = PaddingValues(
                                    start = 14.dp, end = 14.dp, top = 9.dp, bottom = 9.dp
                                ),
                                modifier = Modifier.height(36.dp)
                            )
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Outlined.Schedule,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = "Releases",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Normal,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                },
                                onClick = {
                                    showDetailMenu = false
                                    onNavigateToReleases()
                                },
                                contentPadding = PaddingValues(
                                    start = 14.dp, end = 14.dp, top = 9.dp, bottom = 9.dp
                                ),
                                modifier = Modifier.height(36.dp)
                            )
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Outlined.Person,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = "贡献者",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Normal,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                },
                                onClick = {
                                    showDetailMenu = false
                                    onNavigateToContributors()
                                },
                                contentPadding = PaddingValues(
                                    start = 14.dp, end = 14.dp, top = 9.dp, bottom = 9.dp
                                ),
                                modifier = Modifier.height(36.dp)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                ),
                windowInsets = WindowInsets.statusBars
            )

            // 可滚动内容
            PullToRefreshBox(
                isRefreshing = isRefreshing,
                onRefresh = {
                    isRefreshing = true
                    loadContents(currentPath)
                    loadReadme()
                    isRefreshing = false
                }
            ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
            ) {
                // 仓库信息卡片
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // 所有者行
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { onOwnerClick(repo.owner.login) }
                        ) {
                            AsyncImage(
                                model = repo.owner.avatarUrl,
                                contentDescription = "Avatar",
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                repo.owner.login,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        repo.description?.let {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                it,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                lineHeight = 20.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // 统计行
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(20.dp)
                        ) {
                            // 可点击的星标按钮
                            StarChip(
                                isStarred = isStarred,
                                count = starCount,
                                onClick = { toggleStar() }
                            )
                            StatChip(
                                icon = Icons.Outlined.ForkLeft,
                                label = "Fork",
                                count = repo.forks
                            )
                        }
                    }
                }

                // 面包屑导航
                if (currentPath.isNotEmpty()) {
                    Breadcrumb(
                        currentPath = currentPath,
                        onRootClick = {
                            currentPath = ""
                            pathHistory = emptyList()
                            loadContents("")
                        },
                        onPathClick = { index ->
                            val paths = currentPath.split("/").filter { it.isNotEmpty() }
                            val newPath = paths.take(index + 1).joinToString("/")
                            currentPath = newPath
                            pathHistory = pathHistory.dropLast(paths.size - index - 1)
                            loadContents(newPath)
                        }
                    )
                }

                // 错误信息
                errorMessage?.let { message ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = message,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = { loadContents(currentPath) }) {
                                Text("重试")
                            }
                        }
                    }
                }

                // 文件列表区域
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    // 区域标题 + "+" 按钮
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "文件",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        contents?.let {
                            Text(
                                "${it.size}",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.weight(1f))
                        if (isOwnRepo) {
                            // 上传按钮（点击弹出菜单：选择文件 / 选择文件夹）
                            Box {
                                IconButton(
                                    onClick = { showFileActionMenu = true },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.CloudUpload,
                                        contentDescription = "上传",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                DropdownMenu(
                                    expanded = showFileActionMenu,
                                    onDismissRequest = { showFileActionMenu = false },
                                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                    shape = RoundedCornerShape(14.dp),
                                    shadowElevation = 0.dp,
                                    border = null,
                                    offset = DpOffset(x = (-8).dp, y = 0.dp)
                                ) {
                                    DropdownMenuItem(
                                        text = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.AutoMirrored.Outlined.InsertDriveFile,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Text(
                                                    text = "选择文件",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Normal,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                        },
                                        onClick = {
                                            uploadFileLauncher.launch("*/*")
                                            showFileActionMenu = false
                                        },
                                        contentPadding = PaddingValues(
                                            start = 14.dp, end = 14.dp, top = 9.dp, bottom = 9.dp
                                        ),
                                        modifier = Modifier.height(36.dp)
                                    )
                                    DropdownMenuItem(
                                        text = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Outlined.CreateNewFolder,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Text(
                                                    text = "选择文件夹",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Normal,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                        },
                                        onClick = {
                                            uploadFileLauncher.launch("*/*")
                                            showFileActionMenu = false
                                        },
                                        contentPadding = PaddingValues(
                                            start = 14.dp, end = 14.dp, top = 9.dp, bottom = 9.dp
                                        ),
                                        modifier = Modifier.height(36.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            // 新建文件按钮
                            IconButton(
                                onClick = {
                                    createType = CreateType.FILE
                                    showCreateDialog = true
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Outlined.NoteAdd,
                                    contentDescription = "新建文件",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(2.dp))
                            // 新建文件夹按钮
                            IconButton(
                                onClick = {
                                    createType = CreateType.FOLDER
                                    showCreateDialog = true
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.CreateNewFolder,
                                    contentDescription = "新建文件夹",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    // 文件列表
                    when {
                        isLoading -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        contents.isNullOrEmpty() && errorMessage == null -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(100.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "暂无文件",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 14.sp
                                )
                            }
                        }
                        else -> {
                            val currentContents = contents
                            if (currentContents != null) {
                                Box {
                                    Card(
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = MaterialTheme.colorScheme.surface
                                        ),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                    ) {
                                        currentContents.forEachIndexed { index, item ->
                                            FileListItem(
                                                item = item,
                                                onClick = {
                                                    if (item.type == "dir") {
                                                        pathHistory = pathHistory + currentPath
                                                        currentPath = item.path
                                                        loadContents(item.path)
                                                    } else if (isImageFile(item.name)) {
                                                        onPreviewImage(item.path)
                                                    } else if (isBinaryFile(item.name)) {
                                                        Toast.makeText(context, "不支持预览此文件类型", Toast.LENGTH_SHORT).show()
                                                    } else {
                                                        onPreviewFile(item.path)
                                                    }
                                                },
                                                onLongClick = {
                                                    if (isOwnRepo) contextMenuItem = item
                                                }
                                            )
                                            if (index < currentContents.lastIndex) {
                                                HorizontalDivider(
                                                    modifier = Modifier.padding(start = 48.dp),
                                                    thickness = 0.5.dp,
                                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                                )
                                            }
                                        }
                                    }

                                // 长按弹出菜单 - 只保留重命名和删除
                                androidx.compose.material3.DropdownMenu(
                                    expanded = contextMenuItem != null,
                                    onDismissRequest = { contextMenuItem = null },
                                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                    shape = RoundedCornerShape(14.dp),
                                    shadowElevation = 0.dp,
                                    border = null,
                                    offset = DpOffset(x = (-8).dp, y = 0.dp)
                                ) {
                                    val item = contextMenuItem
                                    if (item != null) {
                                        // 重命名
                                        StyledContextMenuItem(
                                            icon = Icons.Outlined.DriveFileRenameOutline,
                                            label = "重命名",
                                            onClick = {
                                                renameTargetItem = item
                                                renameName = item.name
                                                showRenameDialog = true
                                                contextMenuItem = null
                                            }
                                        )
                                        // 删除
                                        StyledContextMenuItem(
                                            icon = Icons.Outlined.Delete,
                                            label = "删除",
                                            onClick = {
                                                deleteTargetItem = item
                                                showDeleteDialog = true
                                                contextMenuItem = null
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // 返回上一级按钮
                if (pathHistory.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val previousPath = pathHistory.last()
                            pathHistory = pathHistory.dropLast(1)
                            currentPath = previousPath
                            loadContents(previousPath)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            contentColor = MaterialTheme.colorScheme.onSurface
                        )
                    ) {
                        Icon(
                                painter = painterResource(id = R.drawable.ic_arrow_left),
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("返回上一级", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }

                // README 区域
                if (currentPath.isEmpty()) {
                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "README",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    when {
                        isReadmeLoading -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        readmeHtml != null -> {
                            val currentReadmeHtml = readmeHtml
                            if (currentReadmeHtml != null) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surface
                                ),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                AndroidView(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 100.dp)
                                        .padding(12.dp),
                                    factory = { ctx ->
                                        WebView(ctx).apply {
                                            webViewClient = WebViewClient()
                                            settings.apply {
                                                javaScriptEnabled = false
                                                loadWithOverviewMode = true
                                                useWideViewPort = true
                                            }
                                            val styledHtml = wrapReadmeHtml(currentReadmeHtml, isDark)
                                            loadDataWithBaseURL(
                                                "https://github.com",
                                                styledHtml,
                                                "text/html",
                                                "UTF-8",
                                                null
                                            )
                                        }
                                    },
                                    update = { webView ->
                                        val styledHtml = wrapReadmeHtml(currentReadmeHtml, isDark)
                                        webView.loadDataWithBaseURL(
                                            "https://github.com",
                                            styledHtml,
                                            "text/html",
                                            "UTF-8",
                                            null
                                        )
                                    }
                                )
                            }
                            }
                        }
                        else -> {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surface
                                )
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "暂无 README",
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
            }
        }

        // 创建文件/文件夹对话框
        if (showCreateDialog && createType != null) {
            AlertDialog(
                onDismissRequest = {
                    if (!isCreating) {
                        showCreateDialog = false
                        newItemName = ""
                        newFileContent = ""
                    }
                },
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                shape = RoundedCornerShape(20.dp),
                title = {
                    Text(
                        text = if (createType == CreateType.FILE) "创建文件" else "创建文件夹",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                text = {
                    Column {
                        OutlinedTextField(
                            value = newItemName,
                            onValueChange = { newItemName = it },
                            label = { Text("名称") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (createType == CreateType.FILE) {
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = newFileContent,
                                onValueChange = { newFileContent = it },
                                label = { Text("内容") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(120.dp),
                                maxLines = 5
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { createFileOrFolder() },
                        enabled = newItemName.isNotBlank() && !isCreating
                    ) {
                        if (isCreating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("创建")
                        }
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            showCreateDialog = false
                            newItemName = ""
                            newFileContent = ""
                        },
                        enabled = !isCreating
                    ) {
                        Text("取消", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
            )
        }

        // 重命名对话框
        if (showRenameDialog) {
            AlertDialog(
                onDismissRequest = {
                    if (!isRenaming) {
                        showRenameDialog = false
                    }
                },
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                shape = RoundedCornerShape(20.dp),
                title = {
                    val typeName = if (renameTargetItem?.type == "dir") "文件夹" else "文件"
                    Text(
                        text = "重命名$typeName",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                text = {
                    OutlinedTextField(
                        value = renameName,
                        onValueChange = { renameName = it },
                        label = { Text("新名称") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val target = renameTargetItem
                            if (target?.type == "dir") renameFolder() else renameFile()
                        },
                        enabled = renameName.isNotBlank() && !isRenaming
                    ) {
                        if (isRenaming) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("确定")
                        }
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showRenameDialog = false },
                        enabled = !isRenaming
                    ) {
                        Text("取消", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
            )
        }

        // 删除确认对话框
        if (showDeleteDialog) {
            val itemToDelete = deleteTargetItem
            AlertDialog(
                onDismissRequest = {
                    if (!isDeleting) showDeleteDialog = false
                },
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                shape = RoundedCornerShape(20.dp),
                title = {
                    Text(
                        "确认删除",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                text = {
                    val typeName = if (itemToDelete?.type == "dir") "文件夹" else "文件"
                    Text(
                        "确定要删除${typeName}「${itemToDelete?.name ?: ""}」吗？\n\n此操作不可撤销。",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val target = deleteTargetItem
                            if (target?.type == "dir") deleteFolder() else deleteFile()
                        },
                        enabled = !isDeleting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error
                        )
                    ) {
                        if (isDeleting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("删除")
                        }
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showDeleteDialog = false },
                        enabled = !isDeleting
                    ) {
                        Text("取消", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
            )
        }
    }
}
}

@Composable
fun StatChip(
    icon: ImageVector,
    label: String,
    count: Int
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = "$label ${formatCount(count)}",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun StarChip(
    isStarred: Boolean,
    count: Int,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(
                if (isStarred) Color(0xFFFFC107).copy(alpha = 0.15f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Icon(
            imageVector = if (isStarred) Icons.Filled.Star else Icons.Outlined.Star,
            contentDescription = if (isStarred) "已星标" else "添加星标",
            tint = if (isStarred) Color(0xFFFFC107) else MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = "Star ${formatCount(count)}",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium
        )
    }
}

fun formatCount(count: Int): String {
    return when {
        count >= 1000 -> String.format("%.1fk", count / 1000.0)
        else -> count.toString()
    }
}

enum class CreateType {
    FILE, FOLDER
}

@Composable
fun Breadcrumb(
    currentPath: String,
    onRootClick: () -> Unit,
    onPathClick: (Int) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            val paths = currentPath.split("/").filter { it.isNotEmpty() }
            Text(
                "root",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable(onClick = onRootClick)
            )
            paths.forEachIndexed { index, path ->
                Text("/", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    path,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (index == paths.lastIndex) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.primary,
                    modifier = if (index != paths.lastIndex) Modifier.clickable { onPathClick(index) } else Modifier
                )
            }
        }
    }
}

@Composable
fun FileListItem(
    item: RepoContent,
    onClick: () -> Unit,
    onLongClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (item.type == "dir") Icons.Outlined.Folder else Icons.AutoMirrored.Outlined.InsertDriveFile,
            contentDescription = null,
            tint = if (item.type == "dir") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            item.name,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        if (item.type == "file") {
            Text(
                FileSizeFormatter.format(item.size),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

fun wrapReadmeHtml(html: String, isDark: Boolean): String {
    val bgColor = if (isDark) "#0d1117" else "#ffffff"
    val textColor = if (isDark) "#c9d1d9" else "#24292f"
    val linkColor = if (isDark) "#58a6ff" else "#0969da"
    val codeBg = if (isDark) "#161b22" else "#f6f8fa"
    val borderColor = if (isDark) "#30363d" else "#d0d7de"

    return """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    background-color: $bgColor;
                    color: $textColor;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif;
                    font-size: 14px;
                    line-height: 1.6;
                    padding: 16px;
                    word-wrap: break-word;
                }
                a { color: $linkColor; text-decoration: none; }
                a:hover { text-decoration: underline; }
                img { max-width: 100%; height: auto; }
                code {
                    background-color: $codeBg;
                    padding: 2px 6px;
                    border-radius: 4px;
                    font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
                    font-size: 13px;
                }
                pre {
                    background-color: $codeBg;
                    padding: 16px;
                    border-radius: 8px;
                    overflow-x: auto;
                    border: 1px solid $borderColor;
                }
                pre code { padding: 0; background: none; }
                blockquote {
                    border-left: 4px solid $borderColor;
                    padding-left: 16px;
                    margin: 16px 0;
                    color: ${if (isDark) "#8b949e" else "#636c76"};
                }
                h1, h2, h3, h4, h5, h6 {
                    margin-top: 24px;
                    margin-bottom: 16px;
                    font-weight: 600;
                    line-height: 1.25;
                }
                h1 { font-size: 2em; border-bottom: 1px solid $borderColor; padding-bottom: 0.3em; }
                h2 { font-size: 1.5em; border-bottom: 1px solid $borderColor; padding-bottom: 0.3em; }
                h3 { font-size: 1.25em; }
                h4 { font-size: 1em; }
                table {
                    border-collapse: collapse;
                    width: 100%;
                    margin: 16px 0;
                }
                th, td {
                    border: 1px solid $borderColor;
                    padding: 8px 13px;
                }
                th { background-color: $codeBg; }
                hr { border: none; border-top: 1px solid $borderColor; margin: 24px 0; }
                ul, ol { padding-left: 2em; margin: 8px 0; }
                li + li { margin-top: 4px; }
            </style>
        </head>
        <body>
            $html
        </body>
        </html>
    """.trimIndent()
}

@Composable
private fun ColumnScope.StyledContextMenuItem(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    androidx.compose.material3.DropdownMenuItem(
        text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = label,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Normal,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        },
        onClick = onClick,
        contentPadding = PaddingValues(
            start = 14.dp, end = 14.dp, top = 9.dp, bottom = 9.dp
        ),
        modifier = Modifier.height(36.dp)
    )
}

private val imageExtensions = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp", "svg", "ico")

private val textExtensions = setOf(
    "txt", "md", "json", "xml", "yaml", "yml", "toml", "ini", "cfg", "conf", "properties",
    "kt", "java", "swift", "c", "h", "cpp", "hpp", "cs", "go", "rs", "py", "js", "ts", "jsx", "tsx",
    "html", "htm", "css", "scss", "sass", "less", "vue", "svelte",
    "sh", "bash", "zsh", "fish", "ps1", "bat", "cmd",
    "sql", "graphql", "proto",
    "gradle", "groovy", "kts",
    "rb", "php", "pl", "r", "lua", "vim", "el",
    "dockerfile", "makefile", "gitignore", "env",
    "lock", "log", "csv",
    "tf", "hcl", "rego",
    "smali", "dex"
)

fun isImageFile(fileName: String): Boolean {
    val extension = fileName.substringAfterLast('.', "").lowercase()
    return extension in imageExtensions
}

fun isBinaryFile(fileName: String): Boolean {
    val extension = fileName.substringAfterLast('.', "").lowercase()
    // 没有扩展名的文件视为二进制
    if (extension.isEmpty() || extension == fileName.lowercase()) return true
    // 已知文本扩展名
    if (extension in textExtensions) return false
    // 已知图片扩展名
    if (extension in imageExtensions) return true
    // 其他未知扩展名也视为二进制，防止闪退
    return true
}
