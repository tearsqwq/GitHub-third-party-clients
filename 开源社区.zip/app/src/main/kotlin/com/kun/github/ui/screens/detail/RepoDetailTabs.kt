package com.kun.github.ui.screens.detail

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.kun.github.data.model.GithubContributor
import com.kun.github.data.model.GithubIssue
import com.kun.github.data.model.GithubPullRequest
import com.kun.github.data.model.GithubRelease
import com.kun.github.data.repository.user.UserRepository
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.Instant

/**
 * 仓库详情页 Tab 切换组件
 * 
 * 包含 5 个 Tab：文件、Issues、PR、Releases、贡献者
 * 
 * 注意：此组件被放在 RepoDetailScreen 的 verticalScroll Column 中，
 * 因此内部包含 LazyColumn 的内容需要使用固定高度，而非 weight(1f)。
 * weight 在 scrollable 容器中无效。
 */
@Composable
fun RepoDetailTabs(
    token: String,
    owner: String,
    repo: String,
    userRepository: UserRepository,
    onUserClick: (String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabIndex by animateFloatAsState(
        targetValue = selectedTab.toFloat(),
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 300f),
        label = "tabIndex"
    )

    // 获取屏幕高度，用于给 LazyColumn 设置固定高度
    // 因为父容器是 verticalScroll Column，weight(1f) 无效
    val screenHeight = LocalConfiguration.current.screenHeightDp.dp

    Column(modifier = Modifier.fillMaxWidth()) {
        // Tab 切换
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(2.dp)
            ) {
                // 动画背景指示器
                Box(
                    modifier = Modifier
                        .width(46.dp)
                        .height(28.dp)
                        .offset(x = (tabIndex * 50).dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.primary)
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    TabItem("文件", selectedTab == 0) { selectedTab = 0 }
                    TabItem("Issues", selectedTab == 1) { selectedTab = 1 }
                    TabItem("PR", selectedTab == 2) { selectedTab = 2 }
                    TabItem("Releases", selectedTab == 3) { selectedTab = 3 }
                    TabItem("贡献者", selectedTab == 4) { selectedTab = 4 }
                }
            }
        }

        HorizontalDivider(
            thickness = 0.5.dp,
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        )

        // 内容区域
        // 注意：父容器是 verticalScroll Column，不能使用 weight(1f)
        // 对包含 LazyColumn 的 tab 使用固定高度（屏幕高度的 60%）
        AnimatedContent(
            targetState = selectedTab,
            transitionSpec = {
                if (targetState > initialState) {
                    (slideInHorizontally { width -> width } + fadeIn(animationSpec = tween(200)))
                        .togetherWith(slideOutHorizontally { width -> -width } + fadeOut(animationSpec = tween(200)))
                } else {
                    (slideInHorizontally { width -> -width } + fadeIn(animationSpec = tween(200)))
                        .togetherWith(slideOutHorizontally { width -> width } + fadeOut(animationSpec = tween(200)))
                }
            },
            label = "tabContent"
        ) { tab ->
            when (tab) {
                0 -> Text("文件浏览器保持原样", modifier = Modifier.fillMaxWidth())
                1 -> IssuesTab(token, owner, repo, userRepository, screenHeight)
                2 -> PullRequestsTab(token, owner, repo, userRepository, screenHeight)
                3 -> ReleasesTab(token, owner, repo, userRepository, screenHeight)
                4 -> ContributorsTab(token, owner, repo, userRepository, onUserClick, screenHeight)
            }
        }
    }
}

@Composable
private fun TabItem(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .width(46.dp)
            .height(28.dp)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
            color = if (selected) MaterialTheme.colorScheme.onPrimary
            else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/**
 * Issues 列表 Tab
 * 
 * @param screenHeight 屏幕高度，用于设置 LazyColumn 固定高度
 */
@Composable
private fun IssuesTab(
    token: String,
    owner: String,
    repo: String,
    userRepository: UserRepository,
    screenHeight: androidx.compose.ui.unit.Dp
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var issues by remember { mutableStateOf<List<GithubIssue>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var stateFilter by remember { mutableStateOf("open") }

    LaunchedEffect(stateFilter) {
        isLoading = true
        try {
            userRepository.getIssues(token, owner, repo, stateFilter).fold(
                onSuccess = { issues = it },
                onFailure = { issues = emptyList() }
            )
        } catch (e: Exception) {
            issues = emptyList()
        }
        isLoading = false
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        // 筛选
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = stateFilter == "open",
                onClick = { stateFilter = "open" },
                label = { Text("Open") },
                shape = RoundedCornerShape(16.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                )
            )
            FilterChip(
                selected = stateFilter == "closed",
                onClick = { stateFilter = "closed" },
                label = { Text("Closed") },
                shape = RoundedCornerShape(16.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                )
            )
            FilterChip(
                selected = stateFilter == "all",
                onClick = { stateFilter = "all" },
                label = { Text("All") },
                shape = RoundedCornerShape(16.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }

        if (isLoading) {
            Box(modifier = Modifier.fillMaxWidth().height(screenHeight * 0.5f), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(modifier = Modifier.size(36.dp))
            }
        } else if (issues.isEmpty()) {
            EmptyState("暂无 Issues")
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = screenHeight * 0.6f),
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                items(issues, key = { it.id }) { issue ->
                    IssueItem(issue) {
                        issue.htmlUrl?.let { url ->
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        }
                    }
                    HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                }
            }
        }
    }
}

@Composable
private fun IssueItem(issue: GithubIssue, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (issue.state == "open") Icons.Outlined.ErrorOutline else Icons.Outlined.CheckCircle,
            contentDescription = null,
            tint = if (issue.state == "open") Color(0xFF2EA043) else Color(0xFF8957E5),
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = issue.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "#${issue.number}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = formatTime(issue.createdAt),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
            }
        }
        if (issue.comments > 0) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.Schedule,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${issue.comments}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
            }
        }
    }
}

/**
 * Pull Requests 列表 Tab
 * 
 * @param screenHeight 屏幕高度，用于设置 LazyColumn 固定高度
 */
@Composable
private fun PullRequestsTab(
    token: String,
    owner: String,
    repo: String,
    userRepository: UserRepository,
    screenHeight: androidx.compose.ui.unit.Dp
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var prs by remember { mutableStateOf<List<GithubPullRequest>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var stateFilter by remember { mutableStateOf("open") }

    LaunchedEffect(stateFilter) {
        isLoading = true
        try {
            userRepository.getPullRequests(token, owner, repo, stateFilter).fold(
                onSuccess = { prs = it },
                onFailure = { prs = emptyList() }
            )
        } catch (e: Exception) {
            prs = emptyList()
        }
        isLoading = false
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = stateFilter == "open",
                onClick = { stateFilter = "open" },
                label = { Text("Open") },
                shape = RoundedCornerShape(16.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                )
            )
            FilterChip(
                selected = stateFilter == "closed",
                onClick = { stateFilter = "closed" },
                label = { Text("Closed") },
                shape = RoundedCornerShape(16.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }

        if (isLoading) {
            Box(modifier = Modifier.fillMaxWidth().height(screenHeight * 0.5f), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(modifier = Modifier.size(36.dp))
            }
        } else if (prs.isEmpty()) {
            EmptyState("暂无 Pull Requests")
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = screenHeight * 0.6f),
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                items(prs, key = { it.id }) { pr ->
                    PullRequestItem(pr) {
                        pr.htmlUrl?.let { url ->
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        }
                    }
                    HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                }
            }
        }
    }
}

@Composable
private fun PullRequestItem(pr: GithubPullRequest, onClick: () -> Unit) {
    val prColor = when {
        pr.mergedAt != null -> Color(0xFF8957E5)
        pr.state == "open" -> Color(0xFF2EA043)
        else -> Color(0xFFDA3633)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Outlined.Code,
            contentDescription = null,
            tint = prColor,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = pr.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "#${pr.number}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = pr.head?.ref ?: "",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
            }
        }
    }
}

/**
 * Releases 列表 Tab
 * 
 * @param screenHeight 屏幕高度，用于设置 LazyColumn 固定高度
 */
@Composable
private fun ReleasesTab(
    token: String,
    owner: String,
    repo: String,
    userRepository: UserRepository,
    screenHeight: androidx.compose.ui.unit.Dp
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var releases by remember { mutableStateOf<List<GithubRelease>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        isLoading = true
        try {
            userRepository.getReleases(token, owner, repo).fold(
                onSuccess = { releases = it },
                onFailure = { releases = emptyList() }
            )
        } catch (e: Exception) {
            releases = emptyList()
        }
        isLoading = false
    }

    if (isLoading) {
        Box(modifier = Modifier.fillMaxWidth().height(screenHeight * 0.5f), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(modifier = Modifier.size(36.dp))
        }
    } else if (releases.isEmpty()) {
        EmptyState("暂无 Releases")
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = screenHeight * 0.6f),
            verticalArrangement = Arrangement.spacedBy(0.dp)
        ) {
            items(releases, key = { it.id }) { release ->
                ReleaseItem(release) {
                    release.htmlUrl?.let { url ->
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    }
                }
                HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            }
        }
    }
}

@Composable
private fun ReleaseItem(release: GithubRelease, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Outlined.Schedule,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = release.name ?: release.tagName,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = release.tagName,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                if (release.prerelease) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(MaterialTheme.colorScheme.errorContainer)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Pre-release",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
        }
        if (release.assets.isNotEmpty()) {
            Text(
                text = "${release.assets.size} assets",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}

/**
 * 贡献者列表 Tab
 * 
 * @param screenHeight 屏幕高度，用于设置 LazyColumn 固定高度
 */
@Composable
private fun ContributorsTab(
    token: String,
    owner: String,
    repo: String,
    userRepository: UserRepository,
    onUserClick: (String) -> Unit,
    screenHeight: androidx.compose.ui.unit.Dp
) {
    val scope = rememberCoroutineScope()
    var contributors by remember { mutableStateOf<List<GithubContributor>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        isLoading = true
        try {
            userRepository.getContributors(token, owner, repo).fold(
                onSuccess = { contributors = it },
                onFailure = { contributors = emptyList() }
            )
        } catch (e: Exception) {
            contributors = emptyList()
        }
        isLoading = false
    }

    if (isLoading) {
        Box(modifier = Modifier.fillMaxWidth().height(screenHeight * 0.5f), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(modifier = Modifier.size(36.dp))
        }
    } else if (contributors.isEmpty()) {
        EmptyState("暂无贡献者数据")
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = screenHeight * 0.6f),
            verticalArrangement = Arrangement.spacedBy(0.dp)
        ) {
            items(contributors, key = { it.id }) { contributor ->
                ContributorItem(contributor, onUserClick)
                HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            }
        }
    }
}

@Composable
private fun ContributorItem(contributor: GithubContributor, onUserClick: (String) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onUserClick(contributor.login) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = contributor.avatarUrl,
            contentDescription = null,
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = contributor.login,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "${contributor.contributions} contributions",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
        }
    }
}

@Composable
private fun EmptyState(message: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 48.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = message,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
        )
    }
}

private fun formatTime(isoTime: String): String {
    return try {
        val instant = Instant.parse(isoTime)
        val now = Instant.now()
        val duration = Duration.between(instant, now)
        val days = duration.toDays()
        when {
            days < 1 -> "今天"
            days < 2 -> "昨天"
            days < 7 -> "${days}天前"
            days < 30 -> "${days / 7}周前"
            days < 365 -> "${days / 30}个月前"
            else -> "${days / 365}年前"
        }
    } catch (_: Exception) {
        isoTime
    }
}
