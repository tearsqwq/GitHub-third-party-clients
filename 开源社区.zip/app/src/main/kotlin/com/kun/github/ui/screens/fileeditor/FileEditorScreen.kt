package com.kun.github.ui.screens.fileeditor

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Redo
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.SaveAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kun.github.R
import com.kun.github.data.model.GithubRepo
import com.kun.github.data.repository.user.UserRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

// ==================== 代码主题 ====================

data class CodeTheme(
    val name: String,
    val backgroundColor: Color,
    val textColor: Color,
    val gutterColor: Color,
    val gutterTextColor: Color,
    val lineNumberColor: Color,
    val dividerColor: Color,
    val toolbarBgColor: Color,
    val toolbarIconColor: Color,
    val statusBarBgColor: Color,
    val statusBarTextColor: Color,
    val keywordColor: Color,
    val cursorColor: Color,
)

val GitHubLightTheme = CodeTheme(
    name = "GitHub Light",
    backgroundColor = Color(0xFFFAFBFC),
    textColor = Color(0xFF24292F),
    gutterColor = Color(0xFFF1F3F5),
    gutterTextColor = Color(0xFF6E7781),
    lineNumberColor = Color(0xFF57606A),
    dividerColor = Color(0xFFD0D7DE),
    toolbarBgColor = Color(0xFFF6F8FA),
    toolbarIconColor = Color(0xFF24292F),
    statusBarBgColor = Color(0xFFF6F8FA),
    statusBarTextColor = Color(0xFF57606A),
    keywordColor = Color(0xFFCF222E),
    cursorColor = Color(0xFF0969DA),
)

val GitHubDarkTheme = CodeTheme(
    name = "GitHub Dark",
    backgroundColor = Color(0xFF0D1117),
    textColor = Color(0xFFE6EDF3),
    gutterColor = Color(0xFF161B22),
    gutterTextColor = Color(0xFF484F58),
    lineNumberColor = Color(0xFF484F58),
    dividerColor = Color(0xFF21262D),
    toolbarBgColor = Color(0xFF161B22),
    toolbarIconColor = Color(0xFFE6EDF3),
    statusBarBgColor = Color(0xFF161B22),
    statusBarTextColor = Color(0xFF8B949E),
    keywordColor = Color(0xFFFF7B72),
    cursorColor = Color(0xFF58A6FF),
)

val DraculaTheme = CodeTheme(
    name = "Dracula",
    backgroundColor = Color(0xFF282A36),
    textColor = Color(0xFFF8F8F2),
    gutterColor = Color(0xFF21222C),
    gutterTextColor = Color(0xFF6272A4),
    lineNumberColor = Color(0xFF6272A4),
    dividerColor = Color(0xFF44475A),
    toolbarBgColor = Color(0xFF21222C),
    toolbarIconColor = Color(0xFFF8F8F2),
    statusBarBgColor = Color(0xFF191A21),
    statusBarTextColor = Color(0xFF6272A4),
    keywordColor = Color(0xFFFF79C6),
    cursorColor = Color(0xFFF8F8F2),
)

val MonokaiTheme = CodeTheme(
    name = "Monokai",
    backgroundColor = Color(0xFF272822),
    textColor = Color(0xFFF8F8F2),
    gutterColor = Color(0xFF1E1F1C),
    gutterTextColor = Color(0xFF75715E),
    lineNumberColor = Color(0xFF90908A),
    dividerColor = Color(0xFF3E3D32),
    toolbarBgColor = Color(0xFF1E1F1C),
    toolbarIconColor = Color(0xFFF8F8F2),
    statusBarBgColor = Color(0xFF1E1F1C),
    statusBarTextColor = Color(0xFF75715E),
    keywordColor = Color(0xFFF92672),
    cursorColor = Color(0xFFF8F8F0),
)

val SolarizedDarkTheme = CodeTheme(
    name = "Solarized Dark",
    backgroundColor = Color(0xFF002B36),
    textColor = Color(0xFF839496),
    gutterColor = Color(0xFF073642),
    gutterTextColor = Color(0xFF586E75),
    lineNumberColor = Color(0xFF586E75),
    dividerColor = Color(0xFF073642),
    toolbarBgColor = Color(0xFF073642),
    toolbarIconColor = Color(0xFF93A1A1),
    statusBarBgColor = Color(0xFF073642),
    statusBarTextColor = Color(0xFF586E75),
    keywordColor = Color(0xFF859900),
    cursorColor = Color(0xFF93A1A1),
)

val AvailableThemes = listOf(
    GitHubLightTheme,
    GitHubDarkTheme,
    DraculaTheme,
    MonokaiTheme,
    SolarizedDarkTheme
)

// ==================== 编辑器主界面 ====================

@Composable
fun FileEditorScreen(
    repo: GithubRepo,
    filePath: String,
    token: String,
    isEditable: Boolean = false,
    onBack: () -> Unit,
    userRepository: UserRepository
) {
    var textFieldValue by remember { mutableStateOf(TextFieldValue("")) }
    var originalContent by remember { mutableStateOf("") }
    var fileSha by remember { mutableStateOf("") }
    var commitMessage by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(true) }
    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var copySuccess by remember { mutableStateOf(false) }

    // 撤销/重做栈
    val undoStack = remember { mutableListOf<String>() }
    val redoStack = remember { mutableListOf<String>() }
    var lastText by remember { mutableStateOf("") }

    // 主题
    var currentTheme by remember { mutableStateOf(GitHubDarkTheme) }
    var themeMenuExpanded by remember { mutableStateOf(false) }

    // 搜索
    var showSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    // 缩放
    var fontSize by remember { mutableFloatStateOf(14f) }
    var lineNumberWidth by remember { mutableFloatStateOf(52f) }

    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    // 监听文本变化，保存到撤销栈
    LaunchedEffect(textFieldValue.text) {
        if (textFieldValue.text != lastText && lastText.isNotEmpty()) {
            undoStack.add(lastText)
            // 清空重做栈（新编辑后重做失效）
            redoStack.clear()
            // 限制撤销栈大小
            if (undoStack.size > 50) {
                undoStack.removeAt(0)
            }
        }
        lastText = textFieldValue.text
    }

    val fileName = filePath.substringAfterLast("/", filePath)
    val lines = textFieldValue.text.lines()
    val lineCount = lines.size
    val hasChanges = textFieldValue.text != originalContent

    // 加载文件内容
    LaunchedEffect(filePath) {
        isLoading = true
        errorMessage = null
        try {
            val result = userRepository.getFileContent(token, repo.owner.login, repo.name, filePath)
            result.fold(
                onSuccess = { (content, sha) ->
                    textFieldValue = TextFieldValue(content)
                    originalContent = content
                    fileSha = sha
                    commitMessage = "Update $fileName"
                    isLoading = false
                },
                onFailure = { error ->
                    errorMessage = error.message
                    isLoading = false
                }
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            errorMessage = e.message ?: "加载失败"
            isLoading = false
        }
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            // 保存当前状态到重做栈
            redoStack.add(textFieldValue.text)
            // 弹出撤销栈顶
            val previousText = undoStack.removeAt(undoStack.size - 1)
            lastText = previousText
            textFieldValue = TextFieldValue(previousText)
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            // 保存当前状态到撤销栈
            undoStack.add(textFieldValue.text)
            // 弹出重做栈顶
            val nextText = redoStack.removeAt(redoStack.size - 1)
            lastText = nextText
            textFieldValue = TextFieldValue(nextText)
        }
    }

    fun saveFile() {
        if (fileSha.isBlank()) return
        scope.launch {
            isSaving = true
            errorMessage = null
            try {
                val result = userRepository.updateFile(
                    token = token,
                    owner = repo.owner.login,
                    repo = repo.name,
                    path = filePath,
                    content = textFieldValue.text,
                    sha = fileSha,
                    message = commitMessage.ifBlank { "Update $fileName" }
                )
                result.fold(
                    onSuccess = {
                        originalContent = textFieldValue.text
                        onBack()
                    },
                    onFailure = { error ->
                        errorMessage = error.message
                        isSaving = false
                    }
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                errorMessage = e.message ?: "保存失败"
                isSaving = false
            }
        }
    }

    fun copyToClipboard() {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("file_content", textFieldValue.text)
        clipboard.setPrimaryClip(clip)
        copySuccess = true
        Toast.makeText(context, "已复制到剪贴板", Toast.LENGTH_SHORT).show()
        scope.launch {
            kotlinx.coroutines.delay(2000)
            copySuccess = false
        }
    }

    // ==================== Acode 风格 UI ====================

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(currentTheme.backgroundColor)
        ) {
            // ====== 顶部状态栏 ======
            Column(
                modifier = Modifier
                    .background(currentTheme.statusBarBgColor)
                    .statusBarsPadding()
            ) {
                // 标题栏
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 返回按钮
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_arrow_left),
                            contentDescription = "返回",
                            tint = currentTheme.toolbarIconColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // 文件名
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp)
                    ) {
                        Text(
                            text = fileName,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = currentTheme.textColor,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${repo.fullName} · $filePath",
                            fontSize = 11.sp,
                            color = currentTheme.statusBarTextColor,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // 搜索按钮
                    IconButton(
                        onClick = { showSearch = !showSearch },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "搜索",
                            tint = currentTheme.toolbarIconColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // 主题切换
                    Box {
                        IconButton(
                            onClick = { themeMenuExpanded = true },
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Palette,
                                contentDescription = "主题",
                                tint = currentTheme.toolbarIconColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = themeMenuExpanded,
                            onDismissRequest = { themeMenuExpanded = false },
                            containerColor = currentTheme.toolbarBgColor,
                        ) {
                            AvailableThemes.forEach { theme ->
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(14.dp)
                                                    .clip(RoundedCornerShape(3.dp))
                                                    .background(theme.backgroundColor)
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Text(
                                                text = theme.name,
                                                fontSize = 13.sp,
                                                color = if (theme.name == currentTheme.name)
                                                    currentTheme.keywordColor
                                                else
                                                    currentTheme.textColor
                                            )
                                        }
                                    },
                                    onClick = {
                                        currentTheme = theme
                                        themeMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // 复制
                    IconButton(
                        onClick = { copyToClipboard() },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ContentCopy,
                            contentDescription = "复制",
                            tint = if (copySuccess) currentTheme.keywordColor else currentTheme.toolbarIconColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // 保存
                    if (isEditable) {
                        IconButton(
                            onClick = { saveFile() },
                            enabled = hasChanges && !isSaving && !isLoading,
                            modifier = Modifier.size(40.dp)
                        ) {
                            if (isSaving) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = currentTheme.keywordColor
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Outlined.SaveAlt,
                                    contentDescription = "保存",
                                    tint = if (hasChanges) currentTheme.keywordColor else currentTheme.gutterTextColor,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                // 搜索栏
                if (showSearch) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp)
                            .padding(bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = {
                                Text(
                                    "搜索...",
                                    fontSize = 13.sp,
                                    color = currentTheme.gutterTextColor
                                )
                            },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = TextStyle(
                                fontSize = 13.sp,
                                color = currentTheme.textColor
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = currentTheme.keywordColor,
                                unfocusedBorderColor = currentTheme.dividerColor,
                                cursorColor = currentTheme.cursorColor,
                                focusedContainerColor = currentTheme.backgroundColor,
                                unfocusedContainerColor = currentTheme.backgroundColor,
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = { showSearch = false },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Close,
                                contentDescription = "关闭",
                                tint = currentTheme.gutterTextColor,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // 分割线
            HorizontalDivider(
                thickness = 1.dp,
                color = currentTheme.dividerColor
            )

            // ====== 代码编辑区域 ======
            when {
                isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = currentTheme.keywordColor)
                    }
                }
                errorMessage != null -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Text(
                                text = errorMessage ?: "加载失败",
                                color = currentTheme.keywordColor,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = onBack,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = currentTheme.keywordColor
                                )
                            ) {
                                Text("返回", color = Color.White)
                            }
                        }
                    }
                }
                else -> {
                    // 提交信息
                    if (isEditable) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(currentTheme.toolbarBgColor)
                                .padding(horizontal = 12.dp)
                                .padding(top = 8.dp, bottom = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Commit: ",
                                fontSize = 12.sp,
                                color = currentTheme.gutterTextColor,
                                fontWeight = FontWeight.Medium
                            )
                            OutlinedTextField(
                                value = commitMessage,
                                onValueChange = { commitMessage = it },
                                placeholder = {
                                    Text(
                                        "描述你的修改...",
                                        fontSize = 12.sp,
                                        color = currentTheme.gutterTextColor.copy(alpha = 0.6f)
                                    )
                                },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(32.dp),
                                shape = RoundedCornerShape(6.dp),
                                textStyle = TextStyle(
                                    fontSize = 12.sp,
                                    color = currentTheme.textColor
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = currentTheme.keywordColor,
                                    unfocusedBorderColor = currentTheme.dividerColor,
                                    cursorColor = currentTheme.cursorColor,
                                    focusedContainerColor = currentTheme.backgroundColor,
                                    unfocusedContainerColor = currentTheme.backgroundColor,
                                )
                            )
                        }
                    }

                    // 代码编辑区域（可缩放）
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                            .pointerInput(Unit) {
                                detectTransformGestures { _, _, zoom, _ ->
                                    // 双指缩放
                                    val newSize = (fontSize * zoom).coerceIn(8f, 32f)
                                    fontSize = newSize
                                }
                            }
                    ) {
                        Row(modifier = Modifier.fillMaxSize()) {
                            // 左侧行号区域
                            Column(
                                modifier = Modifier
                                    .width(with(LocalDensity.current) { lineNumberWidth.dp })
                                    .fillMaxHeight()
                                    .background(currentTheme.gutterColor)
                            ) {
                                lines.forEachIndexed { index, _ ->
                                    Text(
                                        text = "${index + 1}",
                                        fontSize = fontSize.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = currentTheme.lineNumberColor,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(start = 8.dp, end = 4.dp, top = 1.dp, bottom = 1.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.End
                                    )
                                }
                            }

                            // 右侧代码区域
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .padding(horizontal = 8.dp)
                            ) {
                                if (isEditable) {
                                    // 可编辑模式
                                    BasicTextField(
                                        value = textFieldValue,
                                        onValueChange = { textFieldValue = it },
                                        textStyle = TextStyle(
                                            fontSize = fontSize.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = currentTheme.textColor
                                        ),
                                        cursorBrush = SolidColor(currentTheme.cursorColor),
                                        modifier = Modifier.fillMaxSize(),
                                        decorationBox = { innerTextField ->
                                            Box(modifier = Modifier.fillMaxSize()) {
                                                if (textFieldValue.text.isEmpty()) {
                                                    Text(
                                                        text = if (isEditable) "开始输入..." else "无内容",
                                                        fontSize = fontSize.sp,
                                                        color = currentTheme.gutterTextColor.copy(alpha = 0.5f)
                                                    )
                                                }
                                                innerTextField()
                                            }
                                        }
                                    )
                                } else {
                                    // 只读模式
                                    SelectionContainer {
                                        Text(
                                            text = textFieldValue.text.ifEmpty { " " },
                                            fontSize = fontSize.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = currentTheme.textColor,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ====== 底部工具栏 ======
            HorizontalDivider(
                thickness = 1.dp,
                color = currentTheme.dividerColor
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(currentTheme.toolbarBgColor)
                    .navigationBarsPadding()
                    .imePadding()
                    .height(44.dp)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 撤销
                IconButton(
                    onClick = { undo() },
                    modifier = Modifier.size(36.dp),
                    enabled = undoStack.isNotEmpty()
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.Undo,
                        contentDescription = "撤销",
                        tint = if (undoStack.isNotEmpty()) currentTheme.toolbarIconColor else currentTheme.gutterTextColor,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // 重做
                IconButton(
                    onClick = { redo() },
                    modifier = Modifier.size(36.dp),
                    enabled = redoStack.isNotEmpty()
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.Redo,
                        contentDescription = "重做",
                        tint = if (redoStack.isNotEmpty()) currentTheme.toolbarIconColor else currentTheme.gutterTextColor,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // 缩放提示
                Text(
                    text = "双指缩放",
                    fontSize = 10.sp,
                    color = currentTheme.gutterTextColor.copy(alpha = 0.6f)
                )

                Spacer(modifier = Modifier.weight(1f))

                // 修改状态
                if (hasChanges && isEditable) {
                    Text(
                        text = "● 已修改",
                        fontSize = 11.sp,
                        color = currentTheme.keywordColor,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                }

                // 行数/字符数
                Text(
                    text = "Ln $lineCount · ${textFieldValue.text.length}",
                    fontSize = 11.sp,
                    color = currentTheme.gutterTextColor
                )

                Spacer(modifier = Modifier.weight(1f))

                // 撤销修改
                if (hasChanges && isEditable) {
                    OutlinedButton(
                        onClick = { 
                            textFieldValue = TextFieldValue(originalContent)
                        },
                        enabled = !isSaving,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.height(30.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = currentTheme.keywordColor
                        )
                    ) {
                        Text("还原", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
