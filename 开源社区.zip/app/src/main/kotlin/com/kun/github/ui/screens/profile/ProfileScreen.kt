package com.kun.github.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import android.content.Context
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Error
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kun.github.R
import com.kun.github.ThemeMode
import com.kun.github.presentation.auth.AuthViewModel
import com.kun.github.presentation.components.ContributionCalendar
import com.kun.github.presentation.components.ProfileContent
import com.kun.github.presentation.components.ProfileHeader
import com.kun.github.presentation.components.generateMockContributions
import com.kun.github.presentation.user.ContributionsState
import com.kun.github.presentation.user.UserState
import com.kun.github.presentation.user.UserViewModel
import com.kun.github.presentation.settings.strings
import java.io.File

@Composable
fun ProfileScreen(
    modifier: Modifier = Modifier,
    token: String,
    themeMode: ThemeMode,
    isDarkTheme: Boolean,
    onThemeModeChange: (ThemeMode) -> Unit,
    authViewModel: AuthViewModel,
    userViewModel: UserViewModel,
    cacheDir: File? = null,
    onNavigateToSettings: () -> Unit = {},
    onNavigateToNotifications: () -> Unit = {},
    unreadNotificationCount: Int = 0
) {
    val userState by userViewModel.userState.collectAsState()
    val contributionsState by userViewModel.contributionsState.collectAsState()
    var isRefreshing by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val s = strings()

    // 当用户数据加载完成时，结束刷新动画
    LaunchedEffect(userState) {
        if (userState is UserState.Success || userState is UserState.Error) {
            isRefreshing = false
        }
    }

    // 加载用户数据和贡献数据
    LaunchedEffect(Unit) {
        userViewModel.loadUser(token)
    }

    // 当用户信息加载成功后，加载贡献数据
    LaunchedEffect(userState) {
        if (userState is UserState.Success) {
            val username = (userState as UserState.Success).user.login
            userViewModel.loadContributions(token, username)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        when (val state = userState) {
            is UserState.Loading -> {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
            is UserState.Error -> {
                ErrorContent(message = state.message)
            }
            is UserState.Success -> {
                PullToRefreshBox(
                    isRefreshing = isRefreshing,
                    onRefresh = {
                        isRefreshing = true
                        userViewModel.loadUser(token)
                    }
                ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp)
                ) {
                    Spacer(modifier = Modifier.height(60.dp))

                    // "我的" title row with settings button
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 24.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = s.navProfile,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // 通知铃铛
                            Box {
                                IconButton(
                                    onClick = onNavigateToNotifications
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Notifications,
                                        contentDescription = s.notificationsTitle,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                // 未读红点/数字
                                if (unreadNotificationCount > 0) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .offset(x = (-2).dp, y = (2).dp)
                                            .size(if (unreadNotificationCount > 9) 18.dp else 14.dp)
                                            .background(
                                                color = MaterialTheme.colorScheme.error,
                                                shape = CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (unreadNotificationCount <= 9) {
                                            // 小于等于9显示数字
                                            Text(
                                                text = unreadNotificationCount.toString(),
                                                fontSize = 9.sp,
                                                color = MaterialTheme.colorScheme.onError,
                                                fontWeight = FontWeight.Bold
                                            )
                                        } else {
                                            // 大于9显示红点
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .background(
                                                        color = MaterialTheme.colorScheme.onError,
                                                        shape = CircleShape
                                                    )
                                            )
                                        }
                                    }
                                }
                            }

                            // 设置按钮
                            IconButton(
                                onClick = onNavigateToSettings
                            ) {
                                Icon(
                                    painter = painterResource(id = R.drawable.ic_settings),
                                    contentDescription = s.settingsTitle,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }

                    ProfileHeader(user = state.user)

                    Spacer(modifier = Modifier.height(16.dp))

                    // 贡献日历
                    when (val contribState = contributionsState) {
                        is ContributionsState.Loading -> {
                            ContributionCalendar(
                                contributions = emptyList(),
                                isLoading = true,
                                error = null
                            )
                        }
                        is ContributionsState.Error -> {
                            ContributionCalendar(
                                contributions = emptyList(),
                                isLoading = false,
                                error = contribState.message
                            )
                        }
                        is ContributionsState.Success -> {
                            ContributionCalendar(
                                contributions = contribState.contributions,
                                isLoading = false,
                                error = null,
                                onDayClick = { day ->
                                    // 可以在这里处理点击事件
                                }
                            )
                        }
                        else -> {
                            // Idle 状态显示空数据
                            ContributionCalendar(
                                contributions = emptyList(),
                                isLoading = false,
                                error = null
                            )
                        }
                    }

                    ProfileContent(user = state.user)

                    Spacer(modifier = Modifier.height(80.dp))
                }
                }
            }
            else -> {}
        }
    }
}

@Composable
private fun ErrorContent(message: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Icon(
            imageVector = Icons.Outlined.Error,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(64.dp)
        )
        Text(
            text = message,
            color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center
        )
    }
}
