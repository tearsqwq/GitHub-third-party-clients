package com.kun.github.ui.screens.search

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ForkLeft
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.kun.github.data.model.GithubRepo
import com.kun.github.data.model.GithubUser
import com.kun.github.data.repository.user.UserRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val SEARCH_HISTORY_KEY = "search_history"
private const val MAX_HISTORY_SIZE = 5
private const val SEARCH_DEBOUNCE_MS = 500L

@Composable
fun SearchScreen(
    modifier: Modifier = Modifier,
    token: String,
    userRepository: UserRepository,
    onBack: () -> Unit,
    onRepoClick: (GithubRepo) -> Unit,
    onUserClick: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember {
        context.getSharedPreferences("github_prefs", Context.MODE_PRIVATE)
    }

    // 星标状态缓存
    val starredCache = remember { mutableMapOf<String, Boolean>() }
    
    suspend fun toggleStar(repo: GithubRepo): Boolean {
        val key = "${repo.owner.login}/${repo.name}"
        val isStarred = starredCache[key] ?: false
        return if (isStarred) {
            userRepository.unstarRepo(token, repo.owner.login, repo.name).fold(
                onSuccess = {
                    starredCache[key] = false
                    Toast.makeText(context, "已取消星标", Toast.LENGTH_SHORT).show()
                    true
                },
                onFailure = { false }
            )
        } else {
            userRepository.starRepo(token, repo.owner.login, repo.name).fold(
                onSuccess = {
                    starredCache[key] = true
                    Toast.makeText(context, "已添加星标", Toast.LENGTH_SHORT).show()
                    true
                },
                onFailure = { false }
            )
        }
    }

    var searchQuery by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf(0) } // 0 = Repos, 1 = Users
    var searchJob by remember { mutableStateOf<Job?>(null) }

    // 搜索状态
    var isSearching by remember { mutableStateOf(false) }
    var searchError by remember { mutableStateOf<String?>(null) }
    var repoResults by remember { mutableStateOf<List<GithubRepo>>(emptyList()) }
    var userResults by remember { mutableStateOf<List<GithubUser>>(emptyList()) }
    var totalRepoCount by remember { mutableStateOf(0) }
    var totalUserCount by remember { mutableStateOf(0) }
    var hasSearched by remember { mutableStateOf(false) }

    // 搜索历史
    var searchHistory by remember {
        mutableStateOf(
            prefs.getStringSet(SEARCH_HISTORY_KEY, emptySet())?.toList()?.reversed() ?: emptyList()
        )
    }

    fun saveSearchHistory(query: String) {
        if (query.isBlank()) return
        val current = prefs.getStringSet(SEARCH_HISTORY_KEY, emptySet())?.toMutableSet() ?: mutableSetOf()
        current.add(query)
        // 保留最近5条
        while (current.size > MAX_HISTORY_SIZE) {
            current.remove(current.first())
        }
        prefs.edit().putStringSet(SEARCH_HISTORY_KEY, current).apply()
        searchHistory = prefs.getStringSet(SEARCH_HISTORY_KEY, emptySet())?.toList()?.reversed() ?: emptyList()
    }

    fun clearSearchHistory() {
        prefs.edit().remove(SEARCH_HISTORY_KEY).apply()
        searchHistory = emptyList()
    }

    // 搜索逻辑（带防抖）
    fun performSearch(query: String) {
        if (query.isBlank()) {
            isSearching = false
            hasSearched = false
            searchError = null
            repoResults = emptyList()
            userResults = emptyList()
            totalRepoCount = 0
            totalUserCount = 0
            return
        }

        searchJob?.cancel()
        searchJob = scope.launch {
            delay(SEARCH_DEBOUNCE_MS)
            isSearching = true
            searchError = null

            // 并行搜索仓库和用户
            val repoDeferred = scope.launch {
                userRepository.searchRepositories(token, query).fold(
                    onSuccess = { response ->
                        repoResults = response.items
                        totalRepoCount = response.totalCount
                    },
                    onFailure = { e ->
                        searchError = e.message
                    }
                )
            }

            val userDeferred = scope.launch {
                userRepository.searchUsers(token, query).fold(
                    onSuccess = { response ->
                        userResults = response.items
                        totalUserCount = response.totalCount
                    },
                    onFailure = { e ->
                        if (searchError == null) searchError = e.message
                    }
                )
            }

            repoDeferred.join()
            userDeferred.join()
            isSearching = false
            hasSearched = true
            saveSearchHistory(query)
        }
    }

    // 当搜索框内容变化时触发搜索
    LaunchedEffect(searchQuery) {
        performSearch(searchQuery)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = modifier.fillMaxSize()
        ) {
            // 顶部搜索栏
            SearchBar(
            query = searchQuery,
            onQueryChange = { searchQuery = it },
            onBack = onBack,
            onClear = {
                searchQuery = ""
                isSearching = false
                hasSearched = false
                searchError = null
                repoResults = emptyList()
                userResults = emptyList()
            }
        )

        // 紧凑 Tab 切换 - 带动画
        val tabIndex by animateFloatAsState(
            targetValue = selectedTab.toFloat(),
            animationSpec = spring(
                dampingRatio = 0.7f,
                stiffness = 300f
            ),
            label = "tabIndex"
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(2.dp)
            ) {
                // 动画背景指示器
                Box(
                    modifier = Modifier
                        .width(46.dp)
                        .height(28.dp)
                        .offset(x = (tabIndex * 50).dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.primary)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 仓库
                    Box(
                        modifier = Modifier
                            .width(46.dp)
                            .height(28.dp)
                            .clickable {
                                if (selectedTab != 0) {
                                    selectedTab = 0
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "仓库",
                            fontSize = 13.sp,
                            fontWeight = if (selectedTab == 0) FontWeight.Medium else FontWeight.Normal,
                            color = if (selectedTab == 0) MaterialTheme.colorScheme.onPrimary
                                   else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    // 用户
                    Box(
                        modifier = Modifier
                            .width(46.dp)
                            .height(28.dp)
                            .clickable {
                                if (selectedTab != 1) {
                                    selectedTab = 1
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "用户",
                            fontSize = 13.sp,
                            fontWeight = if (selectedTab == 1) FontWeight.Medium else FontWeight.Normal,
                            color = if (selectedTab == 1) MaterialTheme.colorScheme.onPrimary
                                   else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // 内容区域
        when {
            // 加载中
            isSearching -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "搜索中...",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                    }
                }
            }
            // 错误状态
            searchError != null -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            searchError ?: "搜索失败",
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        androidx.compose.material3.TextButton(onClick = { performSearch(searchQuery) }) {
                            Text("重试", color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
            // 搜索结果为空
            hasSearched && ((selectedTab == 0 && repoResults.isEmpty()) || (selectedTab == 1 && userResults.isEmpty())) -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Outlined.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "未找到相关${if (selectedTab == 0) "仓库" else "用户"}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            fontSize = 14.sp
                        )
                    }
                }
            }
            // 搜索结果 - 带动画
            (selectedTab == 0 && repoResults.isNotEmpty()) || (selectedTab == 1 && userResults.isNotEmpty()) -> {
                AnimatedContent(
                    targetState = selectedTab,
                    transitionSpec = {
                        if (targetState > initialState) {
                            (slideInHorizontally { width -> width } + fadeIn(animationSpec = tween(200)))
                                .togetherWith(slideOutHorizontally { width -> -width } + fadeOut(animationSpec = tween(200)))
                        } else {
                            (slideInHorizontally { width -> -width } + fadeIn(animationSpec = tween(200)))
                                .togetherWith(slideOutHorizontally { width -> width } + fadeOut(animationSpec = tween(200)))
                        }
                    },
                    label = "searchContent"
                ) { tab ->
                    when (tab) {
                        0 -> {
                            Column(modifier = Modifier.fillMaxSize()) {
                                Text(
                                    "共 $totalRepoCount 个仓库",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
                                )
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(12.dp),
                                    contentPadding = PaddingValues(horizontal = 24.dp, vertical = 8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    items(repoResults, key = { it.id }) { repo ->
                                        val key = "${repo.owner.login}/${repo.name}"
                                        val isStarred = starredCache[key] ?: false
                                        SearchRepoItem(
                                            repo = repo,
                                            isStarred = isStarred,
                                            onClick = { onRepoClick(repo) },
                                            onStarClick = {
                                                scope.launch {
                                                    toggleStar(repo)
                                                }
                                            }
                                        )
                                    }
                                }
                            }
                        }
                        1 -> {
                            Column(modifier = Modifier.fillMaxSize()) {
                                Text(
                                    "共 $totalUserCount 个用户",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
                                )
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    contentPadding = PaddingValues(horizontal = 24.dp, vertical = 8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    items(userResults, key = { it.id }) { user ->
                                        SearchUserItem(
                                            user = user,
                                            onClick = { onUserClick(user.login) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // 未搜索，显示搜索历史
            else -> {
                if (searchHistory.isNotEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "搜索历史",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                            Text(
                                "清除",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.clickable { clearSearchHistory() }
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        // 历史标签流式布局
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            searchHistory.forEach { historyItem ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                        .clickable { searchQuery = historyItem }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        historyItem,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Outlined.Search,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                "搜索 GitHub 仓库和用户",
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
    }
}

@Composable
private fun SearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onBack: () -> Unit,
    onClear: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(
                imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                contentDescription = "返回",
                tint = MaterialTheme.colorScheme.onSurface
            )
        }
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp),
            placeholder = {
                Text(
                    "搜索仓库或用户...",
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
            },
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                cursorColor = MaterialTheme.colorScheme.primary
            ),
            leadingIcon = {
                Icon(
                    imageVector = Icons.Outlined.Search,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(20.dp)
                )
            },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = onClear) {
                        Icon(
                            imageVector = Icons.Outlined.Close,
                            contentDescription = "清除",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        )
    }
}

@Composable
private fun SearchRepoItem(
    repo: GithubRepo,
    isStarred: Boolean = false,
    onClick: () -> Unit,
    onStarClick: () -> Unit = {}
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(
                        model = repo.owner.avatarUrl,
                        contentDescription = null,
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        repo.fullName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                // 星标按钮
                IconButton(
                    onClick = onStarClick,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (isStarred) Icons.Filled.Star else Icons.Outlined.Star,
                        contentDescription = if (isStarred) "取消星标" else "添加星标",
                        tint = if (isStarred) Color(0xFFFFC107) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            if (!repo.description.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    repo.description,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 18.sp
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.Star,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        formatCount(repo.stars),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.ForkLeft,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        formatCount(repo.forks),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (!repo.language.isNullOrBlank()) {
                    Text(
                        repo.language,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun SearchUserItem(
    user: GithubUser,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = user.avatarUrl,
                contentDescription = null,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    user.login,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (!user.name.isNullOrBlank()) {
                    Text(
                        user.name,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    "${user.publicRepos} 仓库",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
                Text(
                    "${user.followers} 关注者",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
    }
}

private fun formatCount(count: Int): String {
    return when {
        count >= 1000 -> String.format("%.1fk", count / 1000.0)
        else -> count.toString()
    }
}
