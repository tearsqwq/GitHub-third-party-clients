package com.kun.github.ui.screens.splash

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kun.github.R
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    hasAcceptedTerms: Boolean,
    onSplashComplete: () -> Unit,
    onTermsAccepted: () -> Unit,
    onExitApp: () -> Unit,
    onViewTerms: () -> Unit,
    onViewPrivacy: () -> Unit
) {
    // 动画状态
    var startAnimation by remember { mutableFloatStateOf(0f) }
    var textVisible by remember { mutableFloatStateOf(0f) }
    var showTerms by remember { mutableStateOf(false) }

    // Logo 缩放动画 - 弹性效果
    val logoScale by animateFloatAsState(
        targetValue = if (startAnimation == 1f) 1f else 0.5f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "logoScale"
    )

    // Logo 透明度动画
    val logoAlpha by animateFloatAsState(
        targetValue = startAnimation,
        animationSpec = tween(durationMillis = 600),
        label = "logoAlpha"
    )

    // 文字透明度动画
    val textAlpha by animateFloatAsState(
        targetValue = textVisible,
        animationSpec = tween(durationMillis = 400),
        label = "textAlpha"
    )

    // 启动动画序列
    LaunchedEffect(Unit) {
        // 延迟 100ms 后开始动画
        delay(100)
        startAnimation = 1f
        delay(400)
        textVisible = 1f
        // 如果已经同意协议，直接完成；否则显示协议弹窗
        delay(1500)
        if (hasAcceptedTerms) {
            onSplashComplete()
        } else {
            showTerms = true
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // GitHub Logo
            Icon(
                painter = painterResource(id = R.drawable.ic_github),
                contentDescription = "GitHub Logo",
                modifier = Modifier
                    .size(100.dp)
                    .scale(logoScale)
                    .alpha(logoAlpha),
                tint = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(24.dp))

            // 应用名称
            Text(
                text = "Github",
                fontSize = 36.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.alpha(textAlpha)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Slogan
            Text(
                text = "Build software better, together",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.alpha(textAlpha)
            )
        }

        // 底部版权信息
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 48.dp)
                .alpha(textAlpha),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "© 2025 GitHub, Inc.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "All rights reserved",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
        }

        // 首次使用显示协议弹窗
        if (showTerms && !hasAcceptedTerms) {
            SplashTermsDialog(
                onAccept = {
                    showTerms = false
                    onTermsAccepted()
                },
                onExit = onExitApp,
                onViewTerms = onViewTerms,
                onViewPrivacy = onViewPrivacy
            )
        }
    }
}
