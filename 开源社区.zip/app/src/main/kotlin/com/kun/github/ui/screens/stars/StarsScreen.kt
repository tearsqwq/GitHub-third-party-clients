package com.kun.github.ui.screens.stars

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CallSplit
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kun.github.data.model.GithubRepo
import com.kun.github.data.repository.user.UserRepository
import com.kun.github.data.remote.client.GithubApiClient
import com.kun.github.presentation.components.EmptyStarredState
import com.kun.github.presentation.components.NetworkErrorState
import com.kun.github.presentation.components.RepoItem
import com.kun.github.presentation.components.RepoListSkeleton
import com.kun.github.presentation.user.ReposState
import com.kun.github.presentation.settings.strings
import com.kun.github.presentation.user.UserViewModel
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun StarsScreen(
    modifier: Modifier = Modifier,
    token: String,
    viewModel: UserViewModel,
    userRepository: UserRepository,
    onRepoClick: (GithubRepo) -> Unit = {},
    onOwnerClick: (String) -> Unit = {},
    cacheDir: File? = null
) {
    val starredReposState by viewModel.starredReposState.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val s = strings()

    // 星标状态缓存
    val starredCache = remember { mutableStateOf(setOf<String>()) }

    // 检查星标状态
    fun checkStarredStatus(repos: List<GithubRepo>) {
        scope.launch {
            repos.forEach { repo ->
                launch {
                    val key = "${repo.owner.login}/${repo.name}"
                    userRepository.checkIfStarred(token, repo.owner.login, repo.name).fold(
                        onSuccess = { isStarred ->
                            if (isStarred) {
                                starredCache.value = starredCache.value + key
                            } else {
                                starredCache.value = starredCache.value - key
                            }
                        },
                        onFailure = {}
                    )
                }
            }
        }
    }

    fun toggleStar(repo: GithubRepo) {
        val key = "${repo.owner.login}/${repo.name}"
        scope.launch {
            val isStarred = starredCache.value.contains(key)
            val result = if (isStarred) {
                userRepository.unstarRepo(token, repo.owner.login, repo.name)
            } else {
                userRepository.starRepo(token, repo.owner.login, repo.name)
            }
            result.fold(
                onSuccess = {
                    starredCache.value = if (isStarred) {
                        starredCache.value - key
                    } else {
                        starredCache.value + key
                    }
                    viewModel.loadStarredRepos(token)
                    android.widget.Toast.makeText(
                        context,
                        if (isStarred) "已取消星标" else "已添加星标",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                },
                onFailure = {}
            )
        }
    }

    // 入场动画：标题淡入
    var titleVisible by remember { mutableStateOf(false) }
    val titleAlpha by animateFloatAsState(
        targetValue = if (titleVisible) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMediumLow),
        label = "titleAlpha"
    )

    // 入场动画：列表淡入（延迟）
    var listVisible by remember { mutableStateOf(false) }
    val listAlpha by animateFloatAsState(
        targetValue = if (listVisible) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMediumLow),
        label = "listAlpha"
    )

    // Context menu state for long press
    var contextMenuRepo by remember { mutableStateOf<GithubRepo?>(null) }
    var isRefreshing by remember { mutableStateOf(false) }

    // 当星标仓库数据加载完成时，结束刷新动画
    LaunchedEffect(starredReposState) {
        if (starredReposState is ReposState.Success || starredReposState is ReposState.Error) {
            isRefreshing = false
        }
    }

    // SharedPreferences for pinned repos
    val prefs = remember {
        context.getSharedPreferences("github_prefs", Context.MODE_PRIVATE)
    }

    fun getPinnedRepoIds(): Set<String> {
        return prefs.getStringSet("pinned_repo_ids", emptySet()) ?: emptySet()
    }

    fun togglePinRepo(repoId: Long) {
        val pinnedIds = getPinnedRepoIds().toMutableSet()
        val idStr = repoId.toString()
        if (pinnedIds.contains(idStr)) {
            pinnedIds.remove(idStr)
        } else {
            pinnedIds.add(idStr)
        }
        prefs.edit().putStringSet("pinned_repo_ids", pinnedIds).apply()
    }

    fun isPinned(repoId: Long): Boolean {
        return getPinnedRepoIds().contains(repoId.toString())
    }

    // Fork state
    var isForking by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.loadStarredRepos(token)
        titleVisible = true
    }

    LaunchedEffect(titleAlpha) {
        if (titleAlpha > 0.5f) {
            listVisible = true
        }
    }

    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh = {
            isRefreshing = true
            viewModel.loadStarredRepos(token)
        }
    ) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 24.dp)
    ) {
        Text(
            s.starsTitle,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.alpha(titleAlpha)
        )
        Spacer(modifier = Modifier.height(16.dp))

        when (val state = starredReposState) {
            is ReposState.Loading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp)
                ) {
                    RepoListSkeleton(count = 5)
                }
            }
            is ReposState.Error -> {
                NetworkErrorState(
                    onRetryClick = { viewModel.loadStarredRepos(token) },
                    modifier = Modifier.fillMaxSize()
                )
            }
            is ReposState.Success -> {
                // Sort repos: pinned first
                val sortedRepos = remember(state.repos) {
                    val pinnedIds = getPinnedRepoIds()
                    state.repos.sortedByDescending { pinnedIds.contains(it.id.toString()) }
                }

                // 检查星标状态
                LaunchedEffect(state.repos) {
                    checkStarredStatus(state.repos)
                }

                // 空状态处理
                if (sortedRepos.isEmpty()) {
                    EmptyStarredState(
                        onExploreClick = null,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 100.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .alpha(listAlpha)
                ) {
                    items(sortedRepos, key = { it.id }) { repo ->
                        val key = "${repo.owner.login}/${repo.name}"
                        Box {
                            RepoItem(
                                repo = repo,
                                onClick = { onRepoClick(repo) },
                                onLongClick = { contextMenuRepo = repo },
                                isStarred = starredCache.value.contains(key),
                                onStarClick = { toggleStar(repo) },
                                onOwnerClick = { onOwnerClick(repo.owner.login) }
                            )
                            DropdownMenu(
                                expanded = contextMenuRepo?.id == repo.id,
                                onDismissRequest = { contextMenuRepo = null },
                                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                shape = RoundedCornerShape(14.dp),
                                shadowElevation = 0.dp,
                                border = null,
                                offset = DpOffset(x = (-8).dp, y = 0.dp)
                            ) {
                                StyledContextMenuItem(
                                    icon = Icons.Outlined.PushPin,
                                    label = if (isPinned(repo.id)) s.repoUnpin else s.repoPin,
                                    onClick = {
                                        togglePinRepo(repo.id)
                                        contextMenuRepo = null
                                        viewModel.loadStarredRepos(token)
                                    }
                                )
                                StyledContextMenuItem(
                                    icon = Icons.Outlined.CallSplit,
                                    label = if (isForking) s.repoForking else s.repoFork,
                                    onClick = {
                                        if (isForking) return@StyledContextMenuItem
                                        contextMenuRepo = null
                                        scope.launch {
                                            isForking = true
                                            val result = userRepository.forkRepo(token, repo.owner.login, repo.name)
                                            isForking = false
                                            result.fold(
                                                onSuccess = {
                                                    Toast.makeText(context, s.toastForkSuccess, Toast.LENGTH_SHORT).show()
                                                    // 清除缓存并刷新"我的仓库"列表，确保新复刻的仓库立即可见
                                                    GithubApiClient.refreshClient(token, cacheDir)
                                                    viewModel.loadRepos(token)
                                                },
                                                onFailure = {
                                                    Toast.makeText(context, "${s.toastForkFailed}: ${it.message}", Toast.LENGTH_SHORT).show()
                                                }
                                            )
                                        }
                                    }
                                )
                                StyledContextMenuItem(
                                    icon = Icons.Outlined.ContentCopy,
                                    label = s.repoCopyLink,
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("repo_url", repo.htmlUrl)
                                        clipboard.setPrimaryClip(clip)
                                        Toast.makeText(context, s.toastLinkCopied, Toast.LENGTH_SHORT).show()
                                        contextMenuRepo = null
                                    }
                                )
                                StyledContextMenuItem(
                                    icon = Icons.Outlined.Download,
                                    label = s.repoDownloadZip,
                                    onClick = {
                                        val downloadUrl = userRepository.getZipDownloadUrl(repo.owner.login, repo.name)
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(downloadUrl))
                                        context.startActivity(intent)
                                        contextMenuRepo = null
                                    }
                                )
                            }
                        }
                    }
                }
                }
            }
            else -> {}
        }
    }
    }
}

@Composable
private fun ColumnScope.StyledContextMenuItem(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    DropdownMenuItem(
        text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = label,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Normal,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        },
        onClick = onClick,
        contentPadding = PaddingValues(
            start = 14.dp, end = 14.dp, top = 9.dp, bottom = 9.dp
        ),
        modifier = Modifier.height(36.dp)
    )
}
