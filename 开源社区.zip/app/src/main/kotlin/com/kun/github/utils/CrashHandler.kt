package com.kun.github.utils

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 崩溃处理器 - 应用崩溃时立即显示崩溃页面
 */
object CrashHandler {

    private const val CRASH_DIR = "crash_logs"
    private const val CRASH_FILE_PREFIX = "crash_"
    private const val CRASH_FILE_EXTENSION = ".txt"

    // 保存当前活动的Activity引用
    private var currentActivity: Activity? = null

    /**
     * 注册Activity生命周期回调，用于跟踪当前Activity
     */
    fun registerActivityLifecycleCallbacks(application: Application) {
        application.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityCreated(activity: Activity, savedInstanceState: android.os.Bundle?) {
                currentActivity = activity
            }

            override fun onActivityStarted(activity: Activity) {
                currentActivity = activity
            }

            override fun onActivityResumed(activity: Activity) {
                currentActivity = activity
            }

            override fun onActivityPaused(activity: Activity) {}

            override fun onActivityStopped(activity: Activity) {}

            override fun onActivitySaveInstanceState(activity: Activity, outState: android.os.Bundle) {}

            override fun onActivityDestroyed(activity: Activity) {
                if (currentActivity === activity) {
                    currentActivity = null
                }
            }
        })
    }

    /**
     * 初始化崩溃处理器
     * @param context Application context
     */
    fun init(context: Context) {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                // 生成崩溃日志
                val crashLog = generateCrashLog(context, throwable)
                
                // 保存到文件（用于下次启动时检测）
                saveCrashLogToFile(context, crashLog)
                
                // 获取当前Activity来显示崩溃页面
                val activity = currentActivity
                if (activity != null && !activity.isFinishing && !activity.isDestroyed) {
                    CrashActivity.start(activity, crashLog)
                } else {
                    // 如果没有Activity，尝试从context创建Intent
                    showCrashActivityFromContext(context, crashLog)
                }
            } catch (e: Exception) {
                // 如果显示崩溃页面失败，调用默认处理器
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
    }

    /**
     * 从Context显示崩溃页面
     */
    private fun showCrashActivityFromContext(context: Context, crashLog: String) {
        try {
            val intent = Intent(context, CrashActivity::class.java).apply {
                putExtra(CrashActivity.EXTRA_CRASH_LOG, crashLog)
                putExtra(CrashActivity.EXTRA_APP_PACKAGE, context.packageName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // 如果失败，使用默认处理器
            Thread.getDefaultUncaughtExceptionHandler()?.uncaughtException(
                Thread.currentThread(),
                Exception("无法启动崩溃页面: ${e.message}")
            )
        }
    }

    /**
     * 生成崩溃日志
     */
    private fun generateCrashLog(context: Context, throwable: Throwable): String {
        val stringWriter = StringWriter()
        throwable.printStackTrace(PrintWriter(stringWriter))

        return buildString {
            appendLine("=================== 应用崩溃日志 ===================")
            appendLine("崩溃时间: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}")
            appendLine("应用版本: ${getAppVersion(context)}")
            appendLine("Android 版本: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            appendLine("设备: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine()
            appendLine("=================== 崩溃详情 ===================")
            appendLine(stringWriter.toString())
        }
    }

    /**
     * 保存崩溃日志到文件
     */
    private fun saveCrashLogToFile(context: Context, crashLog: String) {
        try {
            val crashDir = File(context.filesDir, CRASH_DIR)
            if (!crashDir.exists()) {
                crashDir.mkdirs()
            }

            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val crashFile = File(crashDir, "$CRASH_FILE_PREFIX$timestamp$CRASH_FILE_EXTENSION")
            crashFile.writeText(crashLog)
        } catch (e: Exception) {
            // 忽略保存错误
        }
    }

    /**
     * 获取应用版本
     */
    private fun getAppVersion(context: Context): String {
        return try {
            val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            "${packageInfo.versionName} (${packageInfo.versionCode})"
        } catch (e: Exception) {
            "未知"
        }
    }

    /**
     * 获取所有崩溃日志文件
     */
    fun getCrashLogs(context: Context): List<File> {
        val crashDir = File(context.filesDir, CRASH_DIR)
        return if (crashDir.exists()) {
            crashDir.listFiles()
                ?.filter { it.extension == "txt" }
                ?.sortedByDescending { it.lastModified() }
                ?: emptyList()
        } else {
            emptyList()
        }
    }

    /**
     * 读取崩溃日志内容
     */
    fun readCrashLog(file: File): String? {
        return try {
            file.readText()
        } catch (e: Exception) {
            null
        }
    }

    /**
     * 删除崩溃日志
     */
    fun deleteCrashLog(file: File): Boolean {
        return try {
            file.delete()
        } catch (e: Exception) {
            false
        }
    }

    /**
     * 删除所有崩溃日志
     */
    fun deleteAllCrashLogs(context: Context) {
        val crashDir = File(context.filesDir, CRASH_DIR)
        crashDir.listFiles()?.forEach { it.delete() }
    }

    /**
     * 检查是否有崩溃日志
     */
    fun hasCrashLogs(context: Context): Boolean {
        return getCrashLogs(context).isNotEmpty()
    }
}

/**
 * 崩溃日志对话框（用于在设置页查看历史崩溃）
 */
@Composable
fun CrashLogDialog(
    crashLogs: List<File>,
    onDismiss: () -> Unit,
    onClear: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var selectedLog by remember { mutableStateOf(crashLogs.firstOrNull()) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.BugReport,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = "崩溃日志",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                if (crashLogs.size > 1) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        crashLogs.take(3).forEachIndexed { index, file ->
                            val isSelected = selectedLog == file
                            Text(
                                text = "#${index + 1}",
                                fontSize = 12.sp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier
                                    .clickable { selectedLog = file }
                                    .background(
                                        if (isSelected) MaterialTheme.colorScheme.primaryContainer
                                        else Color.Transparent,
                                        RoundedCornerShape(4.dp)
                                    )
                                    .padding(4.dp)
                            )
                        }
                    }
                }

                selectedLog?.let { file ->
                    val content = CrashHandler.readCrashLog(file)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant,
                                RoundedCornerShape(8.dp)
                            )
                            .padding(12.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = content ?: "无法读取日志",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = {
                            selectedLog?.let { file ->
                                CrashHandler.readCrashLog(file)?.let { content ->
                                    clipboardManager.setText(AnnotatedString(content))
                                    Toast.makeText(context, "已复制", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    ) {
                        Icon(Icons.Default.ContentCopy, "复制")
                    }

                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(Icons.Default.Delete, "删除")
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    TextButton(onClick = onClear) {
                        Text("清除全部")
                    }
                    Button(onClick = onDismiss) {
                        Text("关闭")
                    }
                }
            }
        },
        confirmButton = {}
    )

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("确认删除") },
            text = { Text("确定要删除所有崩溃日志吗？") },
            confirmButton = {
                TextButton(
                    onClick = {
                        CrashHandler.deleteAllCrashLogs(context)
                        showDeleteConfirm = false
                        onClear()
                    }
                ) {
                    Text("删除", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("取消")
                }
            }
        )
    }
}
